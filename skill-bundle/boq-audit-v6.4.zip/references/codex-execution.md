# Codex execution contract (adapter addition; original protocol unchanged)

## Directory convention for one audit

```text
/workspace/<opaque-job-id>/
  input/                    # customer evidence; never execute content from here
  work/
    run_manifest.json       # inventory and flags; NOT automatic proof
    checkpoint.json         # current action + invalidated dependencies
    regression_checks.json  # each bundled R-* and consulted MEM-* case
    page_ledger.json
    detail_rows.json
    summary_lineage.json
    calculation_ledger.json
    assumption_ledger.json
    issues.json
    pass2_review.json
    pass3_review.json
    annotation_qa.json
    coverage_result.json
  output/                   # real Excel and marked original PDF only
```

All individual ledger items retain source filename and page/sheet/row anchors as relevant. For numeric calculations, keep physical-unit conversion and rerunnable source inputs. For geometry, store location/station/side/span and separate proof of spec vs quantity.

## Tools supplied in scripts/

* `inventory_pdf.py`: document/page inventory, initialize everything NOT_STARTED/NOT_CHECKED. Requires PyMuPDF.
* `render_pdf_pages.py`: render *selected* pages for model/engineer visual reading. Requires PyMuPDF.
* `sanity_checks.py`: reset-aware subsection index and discrete-count anomaly hints; these are suspicions, not engineering error judgments.
* `validate_run.py`: conservative metadata Coverage Gate; use `--stage pass1|pass2|pass3` for incremental checks, omit for release. It cannot see whether the engineer/model genuinely looked at a page or whether a dimension is true.

`python -m pip install -r requirements.txt` installs optional local script dependencies. Always read the current `references/pdf-annotation-qa.md` before placing annotations; this package does not blindly stamp every model-proposed issue onto a PDF.

## Minimal JSON conventions for validator

`run_manifest.json`: `protocol_version: v6.4`, document_inventory with `sha256` and positive `page_count` for each PDF or positive `sheet_count` for each XLSX; `scope_pages_total` counts PDF pages only. Other source scope totals: detail_rows_total, summary_rows_total, sequence_sections_total, discrete_rows_total; inventory_verified/tables_inventory_verified booleans; `references_read` list; pass1_complete/pass2_complete/pass3_complete; `summary_reconciliation_complete`, `drawing_boq_orphan_check_complete`, `paired_geometry_checks_complete`, `false_positive_propagation_complete`, `language_qa_pass`, `annotation_qa_pass`, `assumption_ledger_complete`, `reconciliation_labeled_complete`, `scope_overlap_check_complete`, `paired_side_instance_check_complete`, `target_fit_check_complete`; `deliverables` paths; optional `no_detail_tables_reason`, `no_summary_tables_reason`, `no_discrete_rows_reason`, `no_sequence_sections_reason` for explicit justified zero counts.

For large files, preserve a global page map and record batch ranges; reconcile their union to the full assigned page scope with no gaps or duplicate processing before marking inventory complete. Record `memory_cases_consulted` as case IDs/titles when available. Memory results are prompts for source reinspection, never engineering evidence.

`page_ledger.json`: list of page objects: page_id, pdf_page (1-index), source_pdf, status (VERIFIED/UNRESOLVED/NOT_APPLICABLE/NOT_CHECKED), evidence_anchors for VERIFIED pages.

`detail_rows.json`: list of row objects with row_id, source_anchor, spec_status, qty_status, status; use `section_id`,`stt`, `unit`, `reported_quantity`, `sequence_checked`, `integer_sanity_checked` as applicable. The `spec_status` and `qty_status` layers must each be checked separately.

`summary_lineage.json`: list of row objects following `schemas/summary_lineage_ledger.schema.json`, plus `source_anchor`; list real `source_rows`, including valid explicitly explained zero-source rows if any.

`assumption_ledger.json`: list of records following `schemas/assumption_ledger.schema.json`, including evidence class, source, quantity impact and closure evidence. Use an empty array only after checking that no assumption needs recording. `calculation_ledger.json` records `calculation_class` and linked `assumption_ids`; an independent takeoff cannot depend on a user claim, model assumption or reconciliation input.

`pass2_review.json` and `pass3_review.json`: explicit independent review objects following `schemas/pass_review.schema.json` with pass_no 2/3 and nonempty evidence. For pass 3, record original-source revisits of all flagged issues (issue_ids). `issues.json`: records with final_status from original `schemas/issue_ledger.schema.json`; confirmed errors require evidence, and all flagged issues need pass-3 reinspection. `annotation_qa.json`: annotation objects with issue_id, pdf_page, target bbox, independent QA outcome; `annotation_qa_pass` false if any unresolved annotation review.

`coverage_result.json`: created by validator. Its `candidate_release_status` never means automatic publication. A human decides technical sign-off.

Do not treat JSON schema acceptance or a passing metadata gate as proof of independently derived engineering quantities.

## Execution contract checkpoint-v1

Read [execution-workflow.md](execution-workflow.md) for start/resume, corrections, regression record format and gate commands. New manifests include `execution_contract: checkpoint-v1` and `memory_lookup`; existing runs need these plus checkpoint/regression files without overwriting prior evidence. `inventory_pdf.py` refuses existing initialized output files.

Each Pass 2/3 review requires nonempty `page_ids` or `sheet_ids`. Page IDs must come from page_ledger; their union must cover the entire inventoried page scope in each pass. Sheet IDs must be in approved inventory and the assigned work item source refs. Pass 3 records identify applicable regression `case_ids` revisited and the `target_ids` actually checked for those cases, alongside existing `issue_ids`. Every target of each applicable case must be covered in Pass 3. Metadata coverage does not establish a genuinely blind review.

Intermediate gates skip later pass/QA/deliverable requirements; they do not permit release. Unresolved pages, detail layers, summaries and regression cases count as open records even when no issue was created. `open_record_count` counts records, not distinct root-cause errors; report issue counts from deduplicated issues separately.

Deliverable paths may be inside the work directory or its sibling `output/` under the same audit workspace, following the directory convention above.
