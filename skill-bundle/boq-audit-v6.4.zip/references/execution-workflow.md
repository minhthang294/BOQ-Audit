# Thực thi có trạng thái — checkpoint-v1

## Bắt đầu / khôi phục

1. Xác định audit workspace và phạm vi user giao. Nếu đã có `work/run_manifest.json`, đọc nó cùng `checkpoint.json`, `regression_checks.json`, gate gần nhất; không gọi inventory để xóa tiến độ. Đối chiếu revision/hash nguồn với manifest; khi thay nguồn, lập attempt mới và giữ kết quả cũ để truy vết.
2. Đọc protocol v6.4 và mười reference bắt buộc trước kết luận kỹ thuật. Đọc regression/reference-cases trước Pass 1. Sau mất ngữ cảnh, đọc lại SKILL + file này và reference của bước đang làm; danh sách `references_read` cũ không chứng minh model hiện còn nhớ nội dung.
3. Đọc memory đúng dự án và các correction đã lưu. Ghi `memory_lookup.status`: FOUND, NO_MATCH hoặc UNAVAILABLE; `sources` là định danh/path thực sự đã đọc, `reason` giải thích nếu không có dữ liệu. Không có công cụ/memory thì tiếp tục với regression đi kèm, báo giới hạn. Không yêu cầu user nhắc lại thông tin đã có trong nguồn truy cập được.
4. Với audit cũ thiếu file mới: thêm checkpoint và checklist với trạng thái NOT_CHECKED, giữ nguyên ledger cũ. Không điền CHECKED/PASS từ tóm tắt hội thoại. Gate chưa đạt cho tới khi kiểm lại phần còn thiếu.

## Vòng làm việc cho mỗi batch

Chọn nhóm trang hữu hạn theo assembly/cấu kiện; ghi global page IDs vào `checkpoint.active_scope`, giữ các liên kết ngoài batch trong ledger. Các batch phải phủ đúng phạm vi một lần, không hở hoặc đếm trùng. Mở nguồn → kiểm → ghi bằng chứng/kết quả → cập nhật checkpoint → báo tiến độ → chuyển batch. Không đợi cuối audit mới tạo ledger. Nếu batch bị gián đoạn mà chưa có kết quả lưu, mở lại nguồn phần đó; không suy hoàn thành từ active_scope.

Checkpoint là con trỏ công việc, không phải bằng chứng:

- `stage`: pass1 / pass2 / pass3 / release.
- `active_scope`: ID trang/dòng/đối tượng đang xử lý.
- `next_action`: thao tác cụ thể tiếp theo, kèm ID/trang cần mở.
- `pending_rechecks`: danh sách `{reason, target_ids, source_anchors}` bị vô hiệu hóa do correction; chỉ bỏ khỏi danh sách sau khi ghi bằng chứng kiểm lại vào ledger tương ứng.
- `blockers`: dữ liệu/tool còn thiếu; xử lý độc lập phần còn làm được.
- `last_gate_report`: tên file gate vừa chạy; gate chỉ có giá trị cho dữ liệu tại thời điểm chạy.

Sau correction của user, revision, geometry hoặc spec: trước tiên lưu claim và mở lại nguồn; ghi pending_rechecks, đổi các trạng thái phụ thuộc thành NOT_CHECKED, xóa pass results phụ thuộc và hạ pass flags từ bước cần làm lại. Tính lại detail → summary → BOQ → estimate và annotation. Gate không được qua khi pending_rechecks còn mục. Nếu mất dấu dependency, mở lại toàn assembly; không tự giữ xanh.

## Checklist lỗi cũ có bằng chứng

`scripts/inventory_pdf.py` tạo `regression_checks.json` từ mọi heading R-* hiện có trong regression.md. Giữ mọi case trong checklist; có thể ghi NOT_APPLICABLE với lý do và anchor phạm vi đã xem, không phải âm thầm bỏ case. Không có bảng FRP là một lý do loại FRP; “chưa thấy lỗi FRP” không phải lý do loại.

Mỗi record:

```json
{
  "case_id": "R-21",
  "title": "Paired-side explicit values",
  "status": "NOT_CHECKED",
  "target_ids": [],
  "evidence_anchors": [],
  "reason": ""
}
```

- CHECKED: `target_ids` đầy đủ cho case trong phạm vi; `evidence_anchors` chỉ rõ nguồn hiện tại; `reason` nêu kết quả cụ thể, kể cả không phát hiện lỗi. Có lỗi thì liên kết issue/CALC trong reason/ledger. Không sao chép các số ví dụ sang dự án mới.
- UNRESOLVED: đã kiểm nhưng thiếu nguồn để kết luận; ghi target IDs, anchor, điều còn thiếu. Vẫn là mục mở, không biến thành xanh.
- NOT_APPLICABLE: ghi lý do không áp dụng dựa trên phạm vi/bản vẽ đã xem và anchor; không cần target IDs.
- NOT_CHECKED: chưa làm; chặn kết thúc Pass 1.

Mỗi bài học memory/correction ngoài bộ R-* thêm ID `MEM-*`, giữ `memory_source`, quy tắc cần kiểm và điều kiện bác bỏ trong title/reason. Liệt kê ID này trong `run_manifest.memory_cases_consulted` để gate bắt case bị bỏ quên. Trường này cũng có thể chứa R-* đã tham chiếu. Định danh/path nguồn memory nằm trong `memory_lookup.sources`, không trộn với ID checklist.

Đánh giá applicability toàn bộ ngay lúc khởi động; hoàn thành checks phù hợp trong Pass 1; Pass 3 tái kiểm nguồn của mọi case CHECKED/UNRESOLVED và ghi `case_ids` tương ứng cùng `target_ids` thực sự đã tái kiểm trong từng review record. Gate đối chiếu hợp các target đã review với toàn bộ target của mỗi case. Một case có nhiều target phải kiểm đủ từng target; một phép tính mẫu không đại diện cho cả case.

## Cổng theo giai đoạn

Chạy từ đường dẫn script đã đọc; WORK là thư mục chứa manifest/ledger:

```sh
python3 SKILL/scripts/validate_run.py WORK --stage pass1
python3 SKILL/scripts/validate_run.py WORK --stage pass2
python3 SKILL/scripts/validate_run.py WORK --stage pass3
python3 SKILL/scripts/validate_run.py WORK
```

| Gate | Bằng chứng bắt buộc thêm ở bước này |
| --- | --- |
| pass1 | Inventory/trang/dòng đầy đủ, refs + memory disposition, checklist lỗi cũ, spec/qty riêng, lineage, CALC inputs/results Pass 1, assumptions, không pending recheck |
| pass2 | Tất cả điều trên + kết quả tính Pass 2, mỗi review có `page_ids` hoặc `sheet_ids` đúng nguồn, hợp `page_ids` phủ mọi trang PDF, method/evidence/result riêng |
| pass3 | Tất cả điều trên + kết quả tính Pass 3, review page coverage, mọi issue đã mở lại, mọi case áp dụng có `case_ids`, đóng/propagate false positive |
| release | Tất cả điều trên + Excel/PDF tồn tại, annotation QA, language QA |

Mỗi gate ghi file `stage_passN_result.json`; release ghi `coverage_result.json`. Exit 2/BLOCKED: quay lại mục thiếu, không sang bước tiếp theo. METADATA_STAGE_COMPLETE có thể có unresolved; ghi rõ số mục mở, tiếp tục các bước còn làm được. Kết quả release READY_FOR_ENGINEER_REVIEW chỉ có nghĩa đủ metadata để chuyển review chuyên môn.

Không dựng cả ba pass bằng cách chép cùng kết quả. Pass 2 bắt đầu từ source inventory và nguồn gốc; ghi kết quả riêng trước khi đối chiếu Pass 1. Nếu model đã thấy kết quả trước, ghi phương pháp trung thực là tái kiểm cùng context, không tự xưng blind độc lập. Khi cần blind thực sự, reviewer với context mới chỉ nhận nguồn, scope và protocol, không nhận đáp án/issue Pass 1; kết quả vẫn phải được kiểm nguồn. Nếu không tổ chức được mức độc lập đã cam kết, báo giới hạn, không dựng cờ hoàn thành giả.

## Kết thúc và học từ correction

Lấy coverage và số mục mở từ ledger/gate; ghi rõ bước thiếu, memory/tool thiếu và phạm vi chưa xác nhận. Báo cáo PARTIAL vẫn giữ mọi unresolved, không gọi “không có lỗi” cho phần chưa kiểm.

Khi user chỉ ra lỗi bị sót: ghi ngay vào checklist của run, mở lại nguồn và dependent outputs. Bài học dùng lại phải có tình huống kích hoạt, cách kiểm, nguồn và điều kiện bác bỏ; lưu trong workspace. Chỉ cập nhật thư viện chung khi có quyền ghi và khi bài học được bằng chứng xác nhận. Không tự biến một correction chưa kiểm chứng thành quy tắc cho mọi công trình.
