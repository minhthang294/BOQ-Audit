#!/usr/bin/env python3
"""Conservative v6.4 METADATA Coverage Gate; cannot verify engineering truth.

Never publishes reports, signs off an audit or invents missing evidence.
"""
import argparse, json, sys, re
from pathlib import Path

MANDATORY_REFS = {
    'references/evidence.md','references/data-and-delivery.md',
    'references/report-language.md','references/detail-table-audit.md',
    'references/functional-closure.md','references/summary-reconciliation.md',
    'references/three-pass-protocol.md','references/anti-false-positive.md',
    'references/sanity-gates.md','references/geometry-assumption-control.md',
    'references/protocol-v6.4.md','references/regression.md',
    'references/reference-cases.md','references/execution-workflow.md',
}
REVIEWED = {'VERIFIED','CONFIRMED_ERROR','UNRESOLVED','INCONSISTENT','NOT_APPLICABLE','CLOSED_WITH_EXPLANATION'}
ISSUE_FINAL = {'CONFIRMED_ERROR','UNRESOLVED','FALSE_POSITIVE','CLOSED_WITH_EXPLANATION','INCONSISTENT'}


def load_json(dir_, stem, issues):
    p=dir_/f'{stem}.json'
    try: return json.loads(p.read_text(encoding='utf8'))
    except (OSError,ValueError) as exc:
        issues.append(f'Missing or malformed {p.name}: {exc}')
        return {} if stem=='run_manifest' else []


def audit(run_dir, stage='release'):
    stage_no={'pass1':1,'pass2':2,'pass3':3,'release':4}[stage]
    root=Path(run_dir).resolve(); failures=[]; open_count=0
    manifest=load_json(root,'run_manifest',failures)
    keys=['page_ledger','detail_rows','summary_lineage','calculation_ledger','issues']
    if stage_no>=2: keys.append('pass2_review')
    if stage_no>=3: keys.append('pass3_review')
    if stage_no>=4: keys.append('annotation_qa')
    tables={key:load_json(root,key,failures) for key in keys}
    if not isinstance(manifest,dict): failures.append('Manifest must be an object');manifest={}
    for key, value in list(tables.items()):
        if not isinstance(value,list): failures.append(key+' must be array');tables[key]=[]
    def fail_if(condition, message):
        if condition: failures.append(message)
    def require_flag(k): fail_if(manifest.get(k) is not True,k+' not positively completed')
    def require_count(k,actual,zero_reason=None):
        total=manifest.get(k)
        if not isinstance(total,int) or isinstance(total,bool) or total<0:
            failures.append(k+' is missing or invalid');return
        if total==0 and zero_reason and not str(manifest.get(zero_reason) or '').strip():
            failures.append(k+'=0 without documented zero-scope reason')
        if total!=actual: failures.append(f'{k}={total} but {actual} ledger records found')
    def unique_rows(rows,k,table):
        seen=set()
        for r in rows:
            ident=r.get(k) if isinstance(r,dict) else None
            if not ident or ident in seen: failures.append(f'{table}: missing or duplicate {k}={ident}')
            seen.add(ident)

    def strings(value):
        return isinstance(value,list) and all(isinstance(v,str) and v.strip() for v in value)
    def nonempty_strings(value):
        return strings(value) and bool(value)

    fail_if(manifest.get('execution_contract')!='checkpoint-v1','Missing execution_contract checkpoint-v1; migrate without overwriting evidence')
    checkpoint=load_json(root,'checkpoint',failures)
    if not isinstance(checkpoint,dict):
        failures.append('checkpoint must be an object');checkpoint={}
    fail_if(checkpoint.get('stage') not in ('pass1','pass2','pass3','release'),'checkpoint stage missing or invalid')
    fail_if(not isinstance(checkpoint.get('next_action'),str) or not checkpoint['next_action'].strip(),'checkpoint next_action missing')
    fail_if(not isinstance(checkpoint.get('pending_rechecks'),list) or bool(checkpoint.get('pending_rechecks')),'Pending rechecks missing or not cleared')
    memory=manifest.get('memory_lookup')
    if not isinstance(memory,dict): memory={}
    fail_if(memory.get('status') not in ('FOUND','NO_MATCH','UNAVAILABLE'),'Memory lookup has no disposition')
    if memory.get('status')=='FOUND':
        fail_if(not nonempty_strings(memory.get('sources')),'Memory FOUND without consulted sources')
    else:
        fail_if(not isinstance(memory.get('reason'),str) or not memory['reason'].strip(),'Memory unavailable/no-match without reason')

    fail_if(manifest.get('protocol_version') not in ('v6.4','6.4'),'Wrong protocol_version')
    inventory=manifest.get('document_inventory')
    expected_pages=set(); expected_page_total=0
    if not isinstance(inventory,list) or not inventory: failures.append('Missing document inventory')
    else:
        doc_ids=set()
        for d in inventory:
            if not isinstance(d,dict):
                failures.append('Invalid document inventory record');continue
            docid=d.get('doc_id');filename=d.get('filename')
            if not isinstance(docid,str) or not docid or docid in doc_ids:
                failures.append('Document inventory has missing or duplicate doc_id')
            doc_ids.add(docid)
            if not isinstance(filename,str) or not filename or not d.get('sha256'):
                failures.append('Document inventory lacks source filename or SHA256 evidence');continue
            is_pdf=filename.lower().endswith('.pdf');is_xlsx=filename.lower().endswith('.xlsx')
            count=d.get('page_count') if is_pdf else d.get('sheet_count') if is_xlsx else None
            if not (is_pdf or is_xlsx) or not isinstance(count,int) or isinstance(count,bool) or count<=0 or (is_pdf and 'sheet_count' in d) or (is_xlsx and 'page_count' in d):
                failures.append('Document inventory lacks valid PDF pages or XLSX sheets');continue
            if is_pdf:
                expected_page_total+=count
                expected_pages.update((f'{docid}-P{page:05d}',filename,page) for page in range(1,count+1))
        if expected_page_total != manifest.get('scope_pages_total'):
            failures.append('Document inventory page total differs from scope')
    require_flag('inventory_verified');require_flag('tables_inventory_verified')
    refs=manifest.get('references_read',[])
    if not strings(refs): failures.append('references_read must be string array');refs=[]
    refs=set(refs)
    fail_if(not MANDATORY_REFS.issubset(refs),'Some original mandatory reference files not recorded as read')
    require_count('scope_pages_total',len(tables['page_ledger']))
    unique_rows(tables['page_ledger'],'page_id','pages')
    actual_pages={(p.get('page_id'),p.get('source_pdf'),p.get('pdf_page')) for p in tables['page_ledger'] if isinstance(p,dict)}
    if expected_pages != actual_pages:
        failures.append('Page ledger does not exactly cover every inventoried document page')
    for page in tables['page_ledger']:
        if not isinstance(page,dict): failures.append('Invalid page ledger record');continue
        if page.get('status') not in REVIEWED: failures.append('Page not reviewed: '+str(page.get('page_id')))
        if page.get('status')=='VERIFIED' and not page.get('evidence_anchors'):
            failures.append('VERIFIED page lacks evidence anchor: '+str(page.get('page_id')))

    regression=load_json(root,'regression_checks',failures)
    if not isinstance(regression,list): failures.append('regression_checks must be array');regression=[]
    bundled=set(re.findall(r'^## (R-\d+) ',(Path(__file__).resolve().parents[1]/'references/regression.md').read_text(encoding='utf8'),re.M))
    consulted=manifest.get('memory_cases_consulted',[])
    if not strings(consulted): failures.append('memory_cases_consulted must be case ID array');consulted=[]
    required_cases=bundled|set(consulted)
    seen_cases=set(); applicable_cases=set(); case_targets={}
    for r in regression:
        if not isinstance(r,dict): failures.append('Invalid regression record');continue
        cid=r.get('case_id')
        if not isinstance(cid,str) or not cid or cid in seen_cases:
            failures.append('Regression missing or duplicate case_id');continue
        seen_cases.add(cid)
        state=r.get('status')
        if state not in ('CHECKED','NOT_APPLICABLE','UNRESOLVED'):
            failures.append(f'Regression {cid} not checked')
        if not nonempty_strings(r.get('evidence_anchors')) or not isinstance(r.get('reason'),str) or not r['reason'].strip():
            failures.append(f'Regression {cid} lacks source evidence/result or non-applicability reason')
        if state in ('CHECKED','UNRESOLVED'):
            applicable_cases.add(cid)
            if not nonempty_strings(r.get('target_ids')): failures.append(f'Regression {cid} lacks targets')
            else: case_targets[cid]=set(r['target_ids'])
        if cid not in bundled and not r.get('memory_source'):
            failures.append(f'Regression {cid} lacks memory source')
        if state=='UNRESOLVED': open_count+=1
    if required_cases-seen_cases:
        failures.append('Missing regression cases: '+', '.join(sorted(required_cases-seen_cases)))

    detail=tables['detail_rows']; summary=tables['summary_lineage']; calcs=tables['calculation_ledger']
    assumptions=load_json(root,'assumption_ledger',failures)
    if not isinstance(assumptions,list): failures.append('assumption_ledger must be array'); assumptions=[]
    unique_rows(assumptions,'assumption_id','assumptions')
    assumption_ids={r.get('assumption_id') for r in assumptions if isinstance(r,dict)}
    for a in assumptions:
        if not isinstance(a,dict): failures.append('Invalid assumption record'); continue
        if a.get('evidence_class') not in ('OBSERVED','DERIVED','USER_CLAIM','MODEL_ASSUMPTION','RECONCILIATION'):
            failures.append('Invalid evidence class for '+str(a.get('assumption_id')))
        if a.get('affects_qty') is True and a.get('evidence_class') in ('USER_CLAIM','MODEL_ASSUMPTION') and not a.get('closure_evidence'):
            open_count+=1
    require_count('detail_rows_total',len(detail),'no_detail_tables_reason')
    require_count('summary_rows_total',len(summary),'no_summary_tables_reason')
    unique_rows(detail,'row_id','detail');unique_rows(summary,'summary_row_id','summary');unique_rows(calcs,'calc_id','calculation')
    detail_ids={r.get('row_id') for r in detail if isinstance(r,dict)}
    for row in detail:
        if not isinstance(row,dict):failures.append('Invalid detail row');continue
        rid=row.get('row_id')
        if not row.get('source_anchor'): failures.append(f'Detail {rid} missing original page/row anchor')
        for layer in ('spec_status','qty_status','status'):
            if row.get(layer) not in REVIEWED: failures.append(f'Detail {rid} {layer} not separately checked')
        if row.get('unit') in ('cái','bộ','biển','lỗ','cọc','gối','khe','thanh','chiếc') and row.get('integer_sanity_checked') is not True:
            failures.append(f'Detail {rid} discrete integer sanity unchecked')
    for row in summary:
        if not isinstance(row,dict):failures.append('Invalid summary row');continue
        rid=row.get('summary_row_id')
        if row.get('status') not in REVIEWED: failures.append(f'Summary {rid} not reconciled')
        if not row.get('source_anchor'): failures.append(f'Summary {rid} missing original page/row anchor')
        src=row.get('source_rows')
        if not isinstance(src,list):failures.append(f'Summary {rid} missing source row list')
        else:
            missing=set(src)-detail_ids
            if missing: failures.append(f'Summary {rid} refers to missing detail IDs {sorted(missing)}')
            if not src and not row.get('zero_source_explanation'):
                failures.append(f'Summary {rid} has no detail source and no explanation')
        if row.get('status')=='VERIFIED' and not all(row.get(k) is True for k in ('name_spec_match','unit_match','scope_match')):
            failures.append(f'Summary {rid} claimed VERIFIED without name/spec/unit/scope parity')
    for c in calcs:
        if not isinstance(c,dict):failures.append('Invalid calculation');continue
        cid=c.get('calc_id')
        if not str(cid).startswith('CALC-') or not c.get('formula') or not c.get('inputs') or not c.get('source_anchors'):
            failures.append(f'Calc {cid} missing formula/inputs/original evidence')
        if not c.get('unit') or c.get('raw_result') is None:failures.append(f'Calc {cid} missing unit or numeric result')
        if any(c.get(f'pass{n}_result') is None for n in range(1,min(stage_no,3)+1)):
            failures.append(f'Calc {cid} lacks required pass result records for {stage}')
        if c.get('calculation_class') not in ('INDEPENDENT_TAKEOFF','RECONCILIATION_CHECK','SENSITIVITY_CHECK'):
            failures.append(f'Calc {cid} missing calculation class')
        for aid in c.get('assumption_ids',[]) or []:
            if aid not in assumption_ids: failures.append(f'Calc {cid} refers to missing assumption {aid}')
        if c.get('calculation_class')=='INDEPENDENT_TAKEOFF':
            linked=[a for a in assumptions if isinstance(a,dict) and a.get('assumption_id') in (c.get('assumption_ids') or [])]
            if any(a.get('evidence_class') not in ('OBSERVED','DERIVED') for a in linked):
                failures.append(f'Calc {cid} independent takeoff relies on non-independent input')
    for k in ('sequence_sections_total','discrete_rows_total'):
        n=manifest.get(k)
        if not isinstance(n,int) or isinstance(n,bool) or n<0:failures.append(k+' missing')
        elif n==0 and not manifest.get('no_'+ ('sequence_sections' if k.startswith('sequence') else 'discrete_rows') +'_reason'):
            failures.append(k+'=0 without documented reason')
        elif manifest.get(k.replace('_total','_checked'))!=n:
            failures.append(k.replace('_total','_checked')+' does not cover entire scope')
    flags=['pass1_complete','summary_reconciliation_complete','drawing_boq_orphan_check_complete',
           'paired_geometry_checks_complete','assumption_ledger_complete','reconciliation_labeled_complete',
           'scope_overlap_check_complete','paired_side_instance_check_complete']
    if stage_no>=2: flags.append('pass2_complete')
    if stage_no>=3: flags.extend(['pass3_complete','false_positive_propagation_complete','target_fit_check_complete'])
    if stage_no>=4: flags.extend(['language_qa_pass','annotation_qa_pass'])
    for flag in flags: require_flag(flag)

    page_ids={p.get('page_id') for p in tables['page_ledger'] if isinstance(p,dict)}
    pass3_cases=set(); reviewed_case_targets={}
    for passnum in range(2,min(stage_no,3)+1):
        key=f'pass{passnum}_review';rows=tables[key]; reviewed_pages=set()
        if not rows: failures.append(f'Independent pass {passnum} ledger is empty')
        unique_rows(rows,'review_id',key)
        for r in rows:
            if not isinstance(r,dict):failures.append('Invalid pass record');continue
            if r.get('pass_no')!=passnum or not r.get('target') or not r.get('evidence') or not r.get('method') or not r.get('result'):
                failures.append(f'Incomplete pass {passnum} review {r.get("review_id")}')
            ids=r.get('page_ids',[]); sheets=r.get('sheet_ids',[])
            if ('page_ids' in r and not nonempty_strings(ids)) or ('sheet_ids' in r and not nonempty_strings(sheets)) or not (ids or sheets):
                failures.append(f'Pass {passnum} review lacks valid page_ids or sheet_ids')
            else: reviewed_pages.update(ids)
            if passnum==3:
                cases=r.get('case_ids',[])
                if not strings(cases): failures.append('Pass 3 case_ids must be string array')
                else:
                    pass3_cases.update(cases)
                    targets=r.get('target_ids',[])
                    if cases and not nonempty_strings(targets): failures.append('Pass 3 case review lacks target_ids')
                    elif strings(targets):
                        for cid in cases: reviewed_case_targets.setdefault(cid,set()).update(targets)
        if reviewed_pages!=page_ids:
            failures.append(f'Pass {passnum} reviews do not exactly cover inventoried pages')
    if stage_no>=3 and applicable_cases-pass3_cases:
        failures.append('Pass 3 did not revisit regression cases: '+', '.join(sorted(applicable_cases-pass3_cases)))
    if pass3_cases-seen_cases: failures.append('Pass 3 references unknown regression cases')
    if stage_no>=3:
        for cid,targets in case_targets.items():
            missing=targets-reviewed_case_targets.get(cid,set())
            if missing: failures.append(f'Pass 3 case {cid} has unchecked targets: '+', '.join(sorted(missing)))

    unique_rows(tables['issues'],'issue_id','issues')
    pass3_targets=set()
    for r in tables.get('pass3_review',[]):
        if isinstance(r,dict):
            pass3_targets.add(r.get('target'));pass3_targets.update(r.get('issue_ids',[]) or [])
    for issue in tables['issues']:
        if not isinstance(issue,dict):failures.append('Invalid issue');continue
        iid=issue.get('issue_id');state=issue.get('final_status')
        if stage_no>=3 and state not in ISSUE_FINAL:failures.append(f'Issue {iid} has no final disposition')
        if stage_no>=3 and iid not in pass3_targets:failures.append(f'Issue {iid} never reopened in Pass 3')
        if state in ('CONFIRMED_ERROR','INCONSISTENT') and not issue.get('evidence'):
            failures.append(f'Issue {iid} lacks corroborating evidence')
        if state in ('UNRESOLVED','INCONSISTENT'):open_count+=1
    for a in tables.get('annotation_qa',[]):
        if not isinstance(a,dict):failures.append('Invalid annotation QA record');continue
        if not a.get('issue_id') or not a.get('pdf_page') or not a.get('target_bbox') or a.get('annotation_qa_status')!='PASS':
            failures.append(f'Annotation QA not complete for {a.get("annotation_id")}')
    required_annotated={i['issue_id'] for i in tables['issues'] if isinstance(i,dict) and i.get('annotation_required') is True}
    completed_ann={a.get('issue_id') for a in tables.get('annotation_qa',[]) if isinstance(a,dict) and a.get('annotation_qa_status')=='PASS'}
    if stage_no>=4 and required_annotated-completed_ann:failures.append('Required annotations not QA verified: '+','.join(sorted(required_annotated-completed_ann)))

    if stage_no>=4:
        deliverables=manifest.get('deliverables') or {}
        for field,extension in (('excel','.xlsx'),('annotated_pdf','.pdf')):
            name=deliverables.get(field)
            if not isinstance(name,str) or not name.endswith(extension): failures.append('Missing deliverable path for '+field);continue
            f=(root/name).resolve()
            allowed=f.is_relative_to(root) or (root.name=='work' and f.is_relative_to(root.parent/'output'))
            if not allowed or not f.is_file() or f.stat().st_size==0:
                failures.append('Deliverable missing or outside audit workdir: '+field)

    for key,layers in (('page_ledger',('status',)),('detail_rows',('status','spec_status','qty_status')),('summary_lineage',('status',))):
        open_count+=sum(1 for r in tables[key] if isinstance(r,dict) and any(r.get(k) in ('UNRESOLVED','INCONSISTENT') for k in layers))
    status=('BLOCKED' if failures else 'PARTIAL_WITH_OPEN_ITEMS_REVIEW_REQUIRED' if open_count else 'READY_FOR_ENGINEER_REVIEW')
    if stage_no<4: status='BLOCKED' if failures else 'METADATA_STAGE_COMPLETE'
    return {'protocol_version':'v6.4','execution_contract':'checkpoint-v1','stage':stage,'gate':'METADATA_ONLY','candidate_release_status':status,
            'automatic_publication_allowed':False,'human_engineer_signoff_required':True,
            'open_issue_count':sum(1 for i in tables['issues'] if isinstance(i,dict) and i.get('final_status') in ('UNRESOLVED','INCONSISTENT')),
            'open_record_count':open_count,'blocking_checks':failures,
            'warning':'Passing metadata checks cannot prove any dimension, quantity, price, three-pass independence, or annotation position is correct.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workdir')
    parser.add_argument('--stage',choices=('pass1','pass2','pass3','release'),default='release')
    parser.add_argument('--out')
    a=parser.parse_args()
    result=audit(a.workdir,a.stage)
    name=a.out or ('coverage_result.json' if a.stage=='release' else f'stage_{a.stage}_result.json')
    dest=Path(a.workdir)/name;dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'stage':a.stage,'candidate_release_status':result['candidate_release_status'],'open_record_count':result['open_record_count'],'blocking_checks':result['blocking_checks'],'report':str(dest)},ensure_ascii=False))
    sys.exit(0 if result['candidate_release_status']!='BLOCKED' else 2)
