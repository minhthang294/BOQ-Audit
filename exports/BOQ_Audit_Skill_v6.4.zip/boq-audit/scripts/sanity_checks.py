#!/usr/bin/env python3
"""Mechanical flags are anomaly hints ONLY, not proof of quantity/spec errors."""
import argparse,json
from decimal import Decimal,InvalidOperation
from pathlib import Path
DISCRETE={'cái','bộ','biển','lỗ','cọc','gối','khe','thanh','chiếc'}

def anomalies(rows):
    flags=[];next_stt={};previous={}
    for index,row in enumerate(rows):
        rid=row.get('row_id',f'INDEX-{index}');unit=str(row.get('unit','')).strip().lower();quantity=row.get('reported_quantity')
        if unit in DISCRETE and quantity is not None and quantity!='':
            try:
                q=Decimal(str(quantity).replace(',','.'))
                if not q.is_finite() or q!=q.to_integral_value(): flags.append(dict(row_id=rid,anomaly='DISCRETE_FRACTION',observed=quantity,unit=unit))
            except InvalidOperation: flags.append(dict(row_id=rid,anomaly='NOT_NUMERIC',observed=quantity,unit=unit))
        sec=row.get('section_id');stt=row.get('stt')
        if sec is not None and stt is not None:
            expect=next_stt.get(sec,1)
            try:
                observed=int(stt)
                if str(stt).strip()!=str(observed): raise ValueError()
                if observed!=expect: flags.append(dict(row_id=rid,anomaly='STT_SEQUENCE',section_id=sec,expected=expect,observed=observed,prior_row=previous.get(sec)))
                next_stt[sec]=observed+1
            except (ValueError,TypeError): flags.append(dict(row_id=rid,anomaly='STT_NOT_INTEGER',section_id=sec,observed=stt))
            previous[sec]=rid
    return flags

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('detail_rows_json');ap.add_argument('--out',required=True)
    a=ap.parse_args();data=json.loads(Path(a.detail_rows_json).read_text(encoding='utf8'))
    if not isinstance(data,list): raise ValueError('Expected list of detail rows')
    results=anomalies(data)
    Path(a.out).write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(f'{len(results)} suspected anomalies, NOT confirmed engineering errors')
