#!/usr/bin/env python3
"""Create PDF and page inventory with NOT_CHECKED placeholders; no engineering verification."""
import argparse, hashlib, json, re
from datetime import datetime, timezone
from pathlib import Path

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def inventory(paths, out):
    import fitz
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    bundle=Path(__file__).resolve().parents[1]
    stems=['detail_rows','summary_lineage','calculation_ledger','assumption_ledger','issues','pass2_review','pass3_review','annotation_qa']
    outputs=['run_manifest','page_ledger','checkpoint','regression_checks',*stems]
    existing=[name for name in outputs if (out/(name+'.json')).exists()]
    if existing: raise FileExistsError('Resume existing ledgers; inventory will not overwrite: '+', '.join(existing))
    docs,pages=[],[]
    for i,name in enumerate(paths,1):
        path=Path(name).expanduser().resolve(strict=True)
        if path.suffix.lower()!='.pdf': raise ValueError('Expected PDF: '+path.name)
        with fitz.open(path) as pdf:
            if pdf.needs_pass: raise ValueError('Password-protected PDF: '+path.name)
            count=pdf.page_count
        docid=f'DOC-{i:03d}'
        docs.append(dict(doc_id=docid,filename=path.name,source_path=str(path),sha256=sha256(path),page_count=count,status='INVENTORIED_ONLY'))
        for n in range(1,count+1):
            pages.append(dict(page_id=f'{docid}-P{n:05d}',source_pdf=path.name,pdf_page=n,printed_sheet=None,drawing_no=None,revision=None,page_type=None,has_quantity_table=False,status='NOT_CHECKED',evidence_anchors=[],notes=None))
    manifest=json.loads((bundle/'templates/run_manifest.json').read_text(encoding='utf8'))
    manifest.update(generated_at=datetime.now(timezone.utc).isoformat(),document_inventory=docs,scope_pages_total=len(pages))
    def write(name, obj): (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    write('run_manifest.json',manifest); write('page_ledger.json',pages)
    for stem in stems: write(stem+'.json',[])
    write('checkpoint.json',json.loads((bundle/'templates/checkpoint.json').read_text(encoding='utf8')))
    cases=re.findall(r'^## (R-\d+) (.+)$',(bundle/'references/regression.md').read_text(encoding='utf8'),re.M)
    write('regression_checks.json',[dict(case_id=cid,title=title,status='NOT_CHECKED',target_ids=[],evidence_anchors=[],reason='') for cid,title in cases])
    return len(docs),len(pages)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('pdf',nargs='+'); ap.add_argument('--out',required=True)
    a=ap.parse_args(); docs,pages=inventory(a.pdf,a.out)
    print(f'Inventoried {docs} PDF(s), {pages} pages; no engineering audit performed.')
