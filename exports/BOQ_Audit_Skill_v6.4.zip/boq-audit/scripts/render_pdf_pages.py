#!/usr/bin/env python3
"""Bounded page renderer; selected pages only. Visual human/model reading still required."""
import argparse
from pathlib import Path

def page_selection(spec,total,max_pages=25):
    pages=[]
    for token in spec.split(','):
        if not token.strip(): raise ValueError('Empty page selector')
        if '-' in token:
            a,b=map(int,token.split('-',1))
            if a>b: raise ValueError('Reversed page range')
            pages.extend(range(a,b+1))
        else: pages.append(int(token))
    pages=list(dict.fromkeys(pages))
    if any(p<1 or p>total for p in pages): raise ValueError(f'Page out of range 1..{total}')
    if len(pages)>max_pages: raise ValueError(f'Render at most {max_pages} pages per batch')
    return pages

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('pdf');ap.add_argument('--pages',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--dpi',type=int,default=160);ap.add_argument('--max-pages',type=int,default=25)
    a=ap.parse_args()
    if a.dpi not in range(72,241) or a.max_pages not in range(1,51): ap.error('dpi 72..240 and max pages 1..50 required')
    import fitz
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    with fitz.open(a.pdf) as pdf:
        for n in page_selection(a.pages,pdf.page_count,a.max_pages):
            pix=pdf[n-1].get_pixmap(matrix=fitz.Matrix(a.dpi/72,a.dpi/72),alpha=False)
            pix.save(out/f'page_{n:05d}.png');print(f'rendered {n}')
