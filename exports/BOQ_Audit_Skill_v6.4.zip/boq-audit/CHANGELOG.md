## v6.4 execution protocol update — 2026-10-26

- Added controller-assigned one-pass batch execution with exact ID scope, explicit JSON patch and evidence outputs, and re-read requirements for each isolated invocation.
- Kept the original three-pass and human engineering review requirements.

### Quy tắc leader và kiểm crop — 2026-10-15
- Yêu cầu leader đi qua khoảng trắng, tránh cắt hàng/cột và chi tiết không liên quan; nếu không có đường sạch thì giữ `UNVERIFIED`.
- QA phải xem riêng từng target crop và note crop, cộng kiểm trang đầy đủ; điểm ảnh tự động không thay kiểm tra che khuất.

### PDF ghi chú trực tiếp — 2026-10-15
- Nâng PDF Annotation QA lên v4: ghi chú tiếng Việt hiển thị ngay trên trang, leader trỏ đúng mục tiêu; cấm comment popup.
- Quy định mark theo span nhỏ nhất, bbox/crop/transform, màu thống nhất cho mark-leader-note và kiểm từng crop sau render cuối.
- Đồng bộ SKILL và protocol v6.4 với các trường note_text, note_bbox và leader.

### PDF annotation precision and severity — 2026-10-15
- Replaced PDF annotation QA v2 with v3: define targets in rendered pixel coordinates, document transform/crop/rotation, calibrate before marking, and inspect every final crop after rendering.
- Require a per-mark Annotation QA ledger; page-level/contact-sheet checks do not establish precise alignment.
- For v3, standardized CRITICAL/HIGH/MEDIUM/LOW/NOTE colors on marks and comment markers (superseded by the v4 on-page note workflow below).
- Keep unverifiable marks out of PASS; disclose and block/partial the annotation gate instead of guessing.

# v6.4 — 2026-10-15

- Phát hành quy trình checkpoint-v1: khôi phục context, checklist lỗi cũ có bằng chứng, gate từng pass, phủ trang/target và kiểm lại dependency sau correction.
- Đồng bộ SKILL, protocol-v6.4, manifest template, validator và tests sang phiên bản 6.4; giữ protocol-v6.3 làm lịch sử.
- Đóng gói đầy đủ tài liệu, schema, template, script và test trong ZIP; không kèm cache Python hoặc dữ liệu audit của khách hàng.
- Audit v6.3 không tự chuyển thành đã kiểm v6.4: giữ bằng chứng cũ, bổ sung checklist và thực hiện kiểm lại theo contract mới.

# v6.3 — 2026-10-01

### Execution hardening — 2026-10-15
- Thêm checkpoint khôi phục context và pending rechecks sau correction; inventory từ chối ghi đè ledger.
- Biến R-01…R-23 và memory cases thành checklist có target/evidence/disposition; case không áp dụng cần lý do từ phạm vi nguồn.
- Thêm gate Pass 1/2/3, page coverage cho review, closure từng target của regression trong Pass 3.
- Unresolved trong trang/detail/summary/case vẫn giữ trạng thái partial dù chưa có issue; tách open records khỏi số lỗi gốc.
- Cho phép output/ cạnh work/ theo convention; bổ sung kiểm thử metadata và hướng dẫn nâng audit cũ.
- Giữ protocol kỹ thuật v6.3 và provenance archive gốc; contract thực thi mới là checkpoint-v1.

### Local hardening — 2026-10-14
- Đồng bộ PDF inventory sang manifest v6.3 và khởi tạo assumption ledger.
- Coverage Gate xác nhận chính xác từng trang nguồn; thêm hồi quy cho trang bị thiếu.
- Quy trình hồ sơ lớn yêu cầu đối soát batch không hở/trùng; memory/MCP chỉ gợi checklist, không thay bằng chứng gốc.
- Cập nhật template manifest và kiểm thử bootstrap inventory.

### Geometry Assumption Control / Anti-Anchoring
- Thêm `references/geometry-assumption-control.md`.
- Thêm `Assumption Ledger` + schema/template.
- Phân loại input: OBSERVED / DERIVED / USER_CLAIM / MODEL_ASSUMPTION / RECONCILIATION.
- User claim phải được cross-view trước khi thay đổi model.
- Cấm back-solve/target-fitting rồi gọi là independent takeoff.
- Complex geometry: lỗ xiên, wave/curve, cutout không được tự thay bằng primitive chưa được dimension khóa.
- Bắt buộc paired-side instance check, không tự ×2.
- Thêm scope partition/no-double-count gate.
- Third Pass bổ sung anti-anchoring, target-fit và reconciliation misuse review.
- Regression R-18…R-23 từ case khe co giãn Cầu Lai/Cầu Cậy.

# v6.2.1 — 2026-09-24

- Bổ sung quy tắc bắt buộc: toàn bộ báo cáo Excel/PDF và tóm tắt người dùng phải bằng tiếng Việt trừ khi được yêu cầu khác.
- Thêm mapping trạng thái và tên sheet tiếng Việt.
- Thêm `references/report-language.md`.
- Coverage Gate không PASS nếu còn nhãn tiếng Anh rò từ schema vào vùng người dùng nhìn thấy.
- Cho phép giữ các viết tắt kỹ thuật chuẩn như BOQ/FRP/PDF/CAD/DV và mã ID.

# Changelog

## v6.2 — 2026-09-24

### Bổ sung bắt buộc từ SCAN0775 / Cầu Kênh Xáng
- **Reset-aware sequence gate**: kiểm continuity STT trong từng subsection, không chỉ uniqueness. Duplicate ở giữa bảng làm toàn bộ tail phải được kiểm expected index; reset chỉ hợp lệ tại header/section rõ.
- **Row-by-row detail↔summary parity**: so tên/spec, đơn vị, giá trị, phạm vi cho từng dòng; không đóng nhóm chỉ vì subtotal khớp.
- **Discrete integer gate** tăng cường: `cái/bộ/biển/lỗ/cọc/gối/khe/thanh` mặc định phải nguyên; số lẻ phải truy nguồn.
- **FRP spec thickness gate**: loại sợi và chiều dày phải thống nhất giữa detail/summary/BOQ; 0,635 ↔ 1,3 mm là lỗi spec dù diện tích đúng.
- **Symmetry / paired-geometry closure**: với cấu kiện chức năng đối xứng, kiểm cặp dimension; khi xác nhận một dimension sai phải recalc toàn bộ downstream.
- **Coverage Gate v6.2**: không PASS nếu chưa kiểm sequence/reset của bảng, discrete quantity sanity, row-level summary lineage, hoặc paired geometry có ảnh hưởng quantity.

### Reference case mới
- Cấu tạo tay vịn lan can (3/3): cả nhóm I nhịp 10 m và 8 m có sequence `1,2,3,4,5,6,5,6,7,8,9,10,11`; đúng phải là `1..13`.
- Các row F1/F1'/O2/O2'/B1/B2/H lần lượt phải là `7/8/9/10/11/12/13`.

## v6.1 — 2026-09-24

### Bổ sung bắt buộc
- Thêm **Third Pass** trước phát hành.
- Third Pass phải:
  - tính lại các phép tính quan trọng từ bằng chứng gốc;
  - rà từng chi tiết nhỏ;
  - soi đơn vị, dấu thập phân, chiều dày, chiều sâu, overlap/chồng mí, offset, biên cong,
    interface, dimension chain, số lượng rời rạc, subtotal và tổng;
  - mở lại mọi issue của pass 1/2 để thử bác bỏ;
  - phân loại issue cuối cùng thành:
    `CONFIRMED_ERROR / UNRESOLVED / FALSE_POSITIVE / CLOSED_WITH_EXPLANATION`;
  - tạo `Third Pass Ledger` và `False Positive Ledger`.
- Coverage Gate chỉ PASS khi `pass1_complete = true`,
  `pass2_complete = true`, `pass3_complete = true`.

### Bài học kích hoạt v6.1
- Hồ sơ phát sinh Cầu Trương Định:
  - cảnh báo 13,195 m² ở trụ T3 trong lượt đầu được Third/forensic logic chứng minh là hợp lý
    khi xét chiều cao hữu hiệu `1,6 + 0,6 - 0,1 = 2,1 m`;
  - lỗi đơn vị sơn chống tia UV `m3` vẫn là lỗi thật;
  - diện tích vuốt nối 40,861 m² tại M1 không đủ hình học để tái lập độc lập nên giữ trạng thái
    `CẦN XÁC NHẬN`, không đoán từ tỷ lệ bản vẽ.

## v6.0 — 2026-09-23

- Workflow hồ sơ lớn ~50–200+ trang / nhiều volume.
- Run Manifest.
- Structured ledgers và data contract.
- Calculation Ledger với `CALC-*`.
- Coverage Gate.
- Optional sub-agent workflow.
- Kiểm tính duy nhất STT/section/index.
- Đối chiếu từng dòng detail ↔ summary, không chỉ kiểm theo nhóm.
- Sanity gate cho đơn vị rời rạc: cái/bộ/biển/lỗ/bao/cọc...
- Blind Second Pass.
- Chuẩn hóa báo cáo Excel/PDF, trạng thái và truy vết.

## v5.8 — 2026-09-16

- Summary Reconciliation Gate.
- Summary Lineage Ledger.
- ORPHAN_SUMMARY_ROW / MISSING_SUMMARY_MAPPING.
- Truy root cause qua detail → subtotal → summary → BOQ/dự toán.
- PDF Annotation QA v2.
