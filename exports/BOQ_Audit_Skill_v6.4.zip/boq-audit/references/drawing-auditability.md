# Drawing Auditability

Khuyến nghị hồ sơ:
- unique physical object IDs;
- same ID across all views/tables;
- explicit quantity dimensions;
- closed dimension chains;
- formula column in quantity tables;
- side/span/layer factors separated;
- structured D/L/t/material fields;
- central design parameters;
- automated title block;
- revision cloud on quantity-impacting changes;
- clear leader endpoints;
- summary generated from detail;
- page/detail reference per BOQ row;
- vector/searchable PDF;
- semantic CAD layers;
- no unnecessary text outlines.


## Bổ sung v6.2
- STT trong mỗi subsection nên tự sinh hoặc kiểm sequence trước phát hành;
- nếu reset STT, phải có header/subsection rõ để người/AI phân biệt reset hợp lệ;
- vật liệu FRP nên tách `fiber_type` và `thickness` thay vì gộp trong text tự do;
- các cặp dimension đối xứng/paired nên có note hoặc common parameter để tránh 250/200 do copy-edit;
- summary nên được generate từ detail để giảm số lẻ phi vật lý và lệch spec/value.
