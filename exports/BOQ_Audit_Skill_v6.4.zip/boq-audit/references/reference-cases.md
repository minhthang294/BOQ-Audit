# Canonical Reference Cases

Các case dưới đây là regression knowledge, không phải dữ liệu của dự án mới.

## 1. Cầu Nậm Nơm — bearing
Sai lầm lịch sử: suy loại gối tại M1 từ pattern.
Rule:
- đọc từng label tại M0/T1/T2/T3/T4/M1;
- anchor đúng support;
- checksum fixed/mobile;
- không extrapolate.

## 2. Cảng Đình Vũ — lưới XG20
Nhiều view xác nhận spec XG20 dày 4 mm không đồng nghĩa khối lượng bảng đúng.
Phải dựng coverage/area và kiểm opening/continuous coverage.

## 3. Cầu Kênh Xáng — máng inox
Dimension 912 không phù hợp functional geometry.
Bề rộng cần phục vụ là 4000; tổng chiều dài máng hợp lý 4600 khi cộng phần thò.
BOQ có thể đúng trong khi chi tiết bản vẽ sai.

## 4. Cầu Kênh Xáng — D18
Mặt bằng D18 L=200; bảng ghi D18 L=160.
Tên dòng là dữ liệu kỹ thuật.
Phải truy tiếp keo/neo/downstream.

## 5. Cầu Kênh Xáng — section / STT
Phát hiện:
- STT lặp;
- Roman section dùng lại;
- detail→summary lệch dòng.
Rule: uniqueness gate + row-by-row reconciliation.

## 6. Cầu Trương Định — false positive
Lượt đầu nghi 13,195 m² bề mặt xử lý trụ T3.
Rà sâu:
`1,6 + 0,6 - 0,1 overlap = 2,1 m`
và:
`2 × π × 1,0 × 2,1 ≈ 13,195 m²`.
Kết luận: cảnh báo phải đóng.

Cùng hồ sơ:
- "Sơn chống tia UV" ghi m3 trong khi quantity là diện tích phủ → lỗi đơn vị.
- area vuốt nối 40,861 m² thiếu geometry đủ để tái lập từ tờ hiện có → UNRESOLVED, không đoán.

## 7. OCR digit
Các số 8/6 hoặc digit nhỏ có thể đọc nhầm.
OCR chỉ locator; số quan trọng phải nhìn ảnh + checksum.


## 8. SCAN0775 Cầu Kênh Xáng — STT lan can (3/3)
Trong cả nhóm I nhịp 10 m và nhóm I nhịp 8 m, sequence hiển thị:
`1,2,3,4,5,6,5,6,7,8,9,10,11`.
Không chỉ hai số 5/6 thứ hai sai; expected sequence của toàn bộ tail bị shift:
- F1 → 7
- F1' → 8
- O2 → 9
- O2' → 10
- B1 → 11
- B2 → 12
- H → 13
Reset I/II/III/IV ở header nhịp 8 m là reset hợp lệ.

## 9. SCAN0775 Cầu Kênh Xáng — discrete summary / FRP spec / symmetry
Các pattern cần bắt:
- detail↔summary lệch từng dòng dù subtotal nhóm có thể trông hợp lý;
- đơn vị `cái` nhưng summary ra số lẻ như 12,833 hoặc 25,665;
- sợi thủy tinh 0,635 mm ở detail nhưng 1,3 mm ở summary;
- mặt cắt gờ lan can paired geometry 250/200, cần symmetry closure và recalc cốt thép downstream.


## 10. Cầu Lai / Cầu Cậy — khe co giãn, bài học v6.3
### Sự cố
- Auditor ban đầu bỏ sót CT5.
- Sau đó CT5 bị hiểu là tấm thẳng 65×22×L theo mô tả hội thoại; nhưng cross-view/module cho thấy geometry không thể khóa chỉ bằng mô tả đó.
- Có lúc cốt thép bổ sung K/C quanh khe bị trộn với khối lượng chế tạo thân khe.
- Có nguy cơ back-solve từ 3.955,646 kg để suy CT2 rồi tuyên bố BOQ đúng.

### Quy tắc khóa
1. User claim chỉ là `USER_CLAIM`, phải kiểm lại bản vẽ.
2. Side A/B tính riêng, không tự ×2.
3. CT1–CT5 thân khe tách khỏi K1/K2/K3/K4/C1/C2/C3 reinforcement.
4. Lỗ xiên CT2 thiếu dimension → `UNRESOLVED_GEOMETRY`, không thay bằng rectangle để chốt.
5. Tấm cong/sóng không tự mô hình hóa circular arc nếu bản vẽ không khóa cung tròn.
6. `target - known parts` chỉ là reconciliation, không phải independent takeoff.
7. Third Pass phải thử phát hiện target-fitting và scope double-counting.
