# Regression Suite

Mỗi bản skill mới phải test tối thiểu các pattern sau.

## R-01 Bearing inference
Không suy fixed/mobile từ pattern.
Phải đọc support line trực tiếp.

## R-02 Mesh/spec vs quantity
Spec đúng không làm quantity đúng.
Phải dựng area/coverage độc lập.

## R-03 Functional dimension
Máng/cover phải phù hợp functional width; phát hiện typo detail dù BOQ đúng.

## R-04 D18 depth mismatch
D18 L=200 vs L=160 phải bắt và truy downstream adhesive.

## R-05 Missing side factor
Một bên vs hai bên phải kiểm tại từng dòng.

## R-06 Repeat factor
Nhịp lặp 2 vs 3 không copy từ nhóm khác.

## R-07 Detail↔Summary mismatch
So từng dòng name/spec/unit/value.

## R-08 Section/STT duplicate
Phát hiện số thứ tự/section copy-paste.

## R-09 Discrete quantity non-integer
Đơn vị cái/bộ/lỗ... có số lẻ phải trigger sanity gate.

## R-10 Small spec typo
Ví dụ 1,0 vs 1,3 mm phải được Third Pass soi lại.

## R-11 Symmetry false assumption
Hai mép/side không tự coi giống nhau; ví dụ 250 vs 200 phải kiểm nguồn.

## R-12 False positive closure
Cảnh báo phải bị đóng nếu overlap/lap/functional dimension giải thích được.
Không duy trì lỗi sai chỉ vì đã report trước.


## R-13 Reset-aware row sequence
Một subsection có `1,2,3,4,5,6,5,6,7,8,9,10,11` phải báo:
- duplicate tại 5/6 thứ hai;
- sequence shift cho toàn bộ tail;
- expected final index = 13.
Reset tại một header/subsection mới phải được nhận diện là hợp lệ, không false positive.

## R-14 Detail↔Summary row parity
Không cho pass khi chỉ biết subtotal nhóm khớp.
Phải bắt name/spec/unit/value lệch ở từng row.

## R-15 Discrete fractional summary
`cái/bộ/biển/lỗ/cọc...` có 12,833; 25,665; 4,069 phải trigger kiểm nguồn.

## R-16 FRP thickness mismatch
Detail 0,635 mm ↔ summary 1,3 mm phải là `MISMATCH_NAME_SPEC`, không bị che bởi area đúng.

## R-17 Symmetry closure + downstream recalc
Khi paired geometry 250/200 được xác định phải là 200/200, không chỉ sửa dimension.
Phải invalidate và tính lại các bar lengths/quantities, subtotal, summary, BOQ và estimate phụ thuộc.


## R-18 User-claim override
Nếu user nói chi tiết là tấm thẳng nhưng drawing cross-view cho thấy chưa thể khóa như vậy, skill phải giữ USER_CLAIM và kiểm bản vẽ trước.

## R-19 Reconciliation masquerading as takeoff
`Target - known parts = missing component` không được đánh dấu independent verified.

## R-20 Complex-geometry primitive assumption
Đường cong/sóng không được tự coi là circular arc; lỗ xiên không được tự coi rectangle nếu thiếu dimension.

## R-21 Paired-side explicit values
Side A và B phải lưu/tính riêng; 5991 + 5990 không được biến thành 5991×2.

## R-22 Scope overlap / double count
Fabricated joint body và supplemental reinforcement phải map sang lineage khác nhau; tổng audit phải bắt cộng trùng.

## R-23 Target-fit detection
Nếu auditor thay đổi model sau khi nhìn BOQ target cho tới khi khớp, Third Pass phải invalidate model và chạy blind rebuild.
