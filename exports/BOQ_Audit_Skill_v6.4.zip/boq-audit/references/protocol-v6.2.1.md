---
name: boq-audit-v6-2-1
description: >
  Bóc tách độc lập từ bản vẽ, rà soát 100% từng dòng BOQ, kiểm hai chiều
  Drawing↔Detail↔Summary↔BOQ↔Estimate, functional geometry, physical instances,
  calculation ledger, coverage gate, 3-pass audit và false-positive closure.
  Ưu tiên cầu, cảng, đường, sửa chữa, FRP, kết cấu thép/BTCT và công trình tạm.
version: "6.2.1"
updated: "2026-09-24"
---

# BOQ AUDIT SKILL v6.2.1

## 0. Mệnh lệnh nền

> **BẢN VẼ / HỒ SƠ KỸ THUẬT LÀ BẰNG CHỨNG. BOQ / BẢNG KHỐI LƯỢNG / DỰ TOÁN LÀ ĐỐI TƯỢNG CẦN KIỂM.**

Không lấy bảng tổng hợp làm đáp án.
Không suy số từ pattern, đối xứng, số thứ tự cuối hoặc tỷ lệ hình vẽ.
Không biến "bảng tự cộng đúng" thành "thiết kế đúng".
Không biến "spec đúng" thành "quantity đúng".
Không biến "quantity đúng" thành "chi tiết bản vẽ đúng".
Không giữ một issue chỉ vì pass trước đã gắn cờ.

## 1. Reference loading policy

### Luôn đọc trước khi kết luận kỹ thuật
- `references/evidence.md`
- `references/data-and-delivery.md`
- `references/report-language.md`
- `references/detail-table-audit.md`
- `references/functional-closure.md`
- `references/summary-reconciliation.md`
- `references/three-pass-protocol.md`
- `references/anti-false-positive.md`
- `references/sanity-gates.md`

### Đọc khi có liên quan
- Bóc tách / công tác kỹ thuật: `references/takeoff.md`
- Dự toán: `references/estimating.md`
- Hồ sơ lớn: `references/large-project-workflow.md`
- Sub-agent: `references/sub-agents.md`
- PDF đánh dấu: `references/pdf-annotation-qa.md`
- Chuẩn hóa hồ sơ: `references/drawing-auditability.md`
- Data schema: `references/structured-data.md`
- Kiểm hồ sơ / section / STT: `references/document-control.md`
- Regression và case: `references/regression.md`, `references/reference-cases.md`

Không được ghi "đã đọc references" nếu chưa thực sự đọc các file cần thiết.

## 2. Run Manifest bắt buộc

Mỗi lần chạy phải ghi:
- `protocol_version = v6.2.1`
- file/volume/page count thực tế;
- phạm vi được giao;
- revision/date nếu có;
- references đã đọc;
- mode: audit BOQ / bóc tách mới / audit dự toán;
- trạng thái Pass 1 / Pass 2 / Pass 3;
- deliverables cần tạo;
- phần hồ sơ thiếu / unreadable / unresolved.

## 3. Chuỗi công việc chuẩn

`INVENTORY`
→ `DOCUMENT CONTROL`
→ `PAGE MAP`
→ `PHYSICAL / GEOMETRY MODEL`
→ `EVIDENCE MAP`
→ `PHYSICAL INSTANCE LEDGER`
→ `CROSS-VIEW`
→ `LAYER A SPEC`
→ `LAYER B GEOMETRY / QTY`
→ `FUNCTIONAL CLOSURE`
→ `DETAIL TABLE 100%`
→ `SUMMARY RECONCILIATION`
→ `BOQ`
→ `ESTIMATE / DOWNSTREAM`
→ `CALCULATION LEDGER`
→ `FIRST PASS CLOSE`
→ `SECOND PASS BLIND`
→ `THIRD PASS FORENSIC`
→ `FALSE-POSITIVE CLOSURE`
→ `COVERAGE GATE`
→ `EXCEL + PDF QA`
→ `RELEASE`

## 4. Inventory và document control

- Xác định số trang PDF thực.
- Đọc từ trang 1 đến trang cuối trong phạm vi.
- Lập ledger mọi trang:
  - project_name
  - owner/client
  - location
  - drawing_title
  - drawing_no
  - sheet_no
  - revision
  - issue/date
  - page type
  - table present?
- Kiểm:
  - số tờ trùng;
  - STT lặp;
  - STT nhảy;
  - Roman/section lặp sai do copy-paste;
  - sequence từng subsection: sau khi loại trừ reset hợp lệ ở header mới, STT phải tăng liên tục 1..N hoặc theo rule được ghi rõ;
  - nếu gặp duplicate, không chỉ flag ô trùng mà phải kiểm toàn bộ các dòng phía sau có bị lệch chuỗi đánh số hay không;
  - số dòng vật lý trong subsection phải khớp số index mong đợi, để bắt cả dòng thiếu dù STT cuối vẫn có vẻ hợp lý;
  - title block sai dự án;
  - tên chi tiết không khớp thân hình;
  - revision bất thường.
- Reset STT chỉ được coi hợp lệ khi có ranh giới section/subsection rõ ràng.
- Không bỏ qua trang không có bảng KL.

## 5. Mô hình vật lý trước BOQ

Khóa tối thiểu khi hồ sơ cho phép:
- nhịp và chiều dài từng nhịp;
- mố/trụ/support line;
- số dầm / số đầu dầm;
- bề rộng cầu;
- trái/phải, thượng/hạ lưu;
- số gối, khe, cọc, lan can, biển;
- cấu kiện hiện hữu / mới / sửa;
- temporary works;
- phạm vi sửa chữa.

Không suy số cấu kiện từ ID cuối.
Không tự nhân 2 nếu chưa có bằng chứng hai phía.

## 6. Physical Instance Ledger

Với cấu kiện lặp:
- lập `instance_id`;
- station/vị trí;
- side;
- span/support;
- view_evidence;
- included/excluded;
- quantity factor.

Số lượng BOQ không được dùng làm input đếm instance.

## 7. Cross-view và leader

Map đúng cùng một cấu kiện qua:
- mặt bằng;
- mặt đứng/dọc;
- mặt cắt ngang;
- chi tiết;
- bảng KL;
- note;
- title/caption.

Phải lần đúng đầu leader / arrow.
Nhiều hình copy từ cùng nguồn không phải bằng chứng độc lập.
Một callout lệch chưa đủ để đổi mô hình.

## 8. Layer A / Layer B

### Layer A — Spec
Kiểm riêng:
- tên;
- vật liệu;
- D;
- L;
- B/H;
- t;
- mác/cấp bền;
- lớp phủ;
- chiều sâu khoan;
- tiêu chuẩn;
- loại FRP/lưới/thép;
- với FRP: loại sợi + chiều dày phải được so độc lập giữa detail, note, summary và BOQ; sai 0,635 ↔ 1,3 mm là lỗi spec kể cả diện tích vẫn đúng.

### Layer B — Geometry/Quantity
Kiểm riêng:
- count;
- length;
- area;
- volume;
- span factor;
- side factor;
- number of layers;
- formula;
- unit conversion;
- mass.

Layer A đúng không làm Layer B đúng và ngược lại.

## 9. Functional geometry / work-chain

Cho mỗi công tác:
`parent geometry → prerequisite work → main work → downstream work`.

Hỏi:
- cấu kiện này lắp ở đâu?
- phải phủ / vượt / neo / hứng / tiếp xúc phần nào?
- dimension nào chi phối chức năng?
- có overlap/chồng mí?
- có opening/cutout/gross-net?
- interface hai phía có tương thích?

Bắt buộc dùng functional chain để phát hiện typo mà bảng KL có thể vẫn đúng.

### Symmetry / paired-geometry closure
- Không được tự giả định hai bên đối xứng chỉ vì hình trông đối xứng.
- Nếu thiết kế/chức năng chứng minh hai bên tương đương, phải so trực tiếp các kích thước paired left↔right.
- Khi một bên 250 và bên kia 200 nhưng overall/chi tiết/assembly chứng minh phải bằng nhau, phải mở issue geometry.
- Sau khi sửa một dimension gốc, bắt buộc truy tất cả downstream geometry và tính lại: bar length, steel mass, concrete, formwork, weld, plate/tube length, subtotal, summary, BOQ, estimate.
- Không được giữ bảng cũ xanh chỉ vì phép nhân theo chiều dài cũ tự khớp.

## 10. Detail-table 100%

Với bảng N dòng:
> `Đã kiểm N/N dòng`

Trước khi kiểm số học, phải kiểm cấu trúc bảng:
- section/subsection boundary;
- STT đầu-cuối;
- duplicate/missing/jump;
- reset có hợp lệ không;
- số row vật lý có khớp sequence mong đợi không.

Mỗi dòng kiểm:
1. STT/row ID và vị trí trong sequence;
2. tên;
3. spec;
4. D/L/B/H/t/material;
5. số lượng;
6. hệ số;
7. đơn vị;
8. đơn trọng;
9. công thức;
10. khối lượng dòng;
11. subtotal;
12. total;
13. mapping summary;
14. downstream BOQ/estimate.

Với đơn vị rời rạc (`cái/bộ/biển/lỗ/cọc/gối/khe/thanh`), giá trị lẻ phải trigger kiểm ngược nguồn trước khi chấp nhận.

Không biết → không đoán → giữ OPEN/YELLOW.

## 11. Summary Reconciliation Gate

Phải xác định tất cả trang/bảng tổng hợp.
Map từng dòng tổng hợp về nguồn detail:
- name/spec;
- unit;
- value;
- scope;
- revision;
- aggregation rule.

Kiểm cả hai chiều:
- detail → summary;
- summary → detail.

Các trạng thái:
- `OK`
- `ORPHAN_SUMMARY_ROW`
- `MISSING_SUMMARY_MAPPING`
- `MISMATCH_NAME_SPEC`
- `MISMATCH_UNIT`
- `MISMATCH_VALUE`
- `OPEN_SOURCE`

Không được chỉ kết luận "nhóm khớp".

Mỗi dòng detail↔summary phải so đồng thời `name/spec + unit + value + scope`.
Nếu summary dùng đơn vị rời rạc mà ra số lẻ, phải coi là anomaly cho đến khi có quy tắc quy đổi hợp lệ.
Nếu detail đổi geometry/spec sau correction, summary mapping phải được chạy lại từ nguồn mới, không copy delta cũ.

## 12. Calculation Ledger

Mỗi phép tính quan trọng có:
- `calc_id = CALC-*`;
- object/work_item;
- formula;
- inputs;
- units;
- source pages/detail IDs;
- raw result;
- rounded result;
- rounding rule;
- pass1 result;
- pass2 result;
- pass3 result;
- final status.

Phép tính phải chạy lại được.
Không dùng suy ngược BOQ làm bằng chứng cuối.

## 13. Sanity Gates

Luôn chạy:
- unit type sanity;
- discrete count sanity;
- sign/zero sanity;
- magnitude sanity;
- duplicate-vector anomaly;
- section/index uniqueness;
- reset-aware sequence continuity;
- detail↔summary row parity;
- unit consistency;
- spec-thickness consistency;
- dimension chain closure;
- paired/symmetry geometry consistency;
- interface compatibility;
- functional coverage sanity.

Đơn vị rời rạc như:
`cái, bộ, biển, lỗ, bao, cọc`
phải là số nguyên, trừ khi hồ sơ có lý do đo bóc rõ ràng.

## 14. Bearing rule

Không suy fixed/mobile từ pattern, alternation, symmetry hoặc "thường phải như vậy".
Mỗi support line phải đọc trực tiếp từng bearing label và anchor đúng support.
Checksum fixed/mobile độc lập.
Không extrapolate từ support bên cạnh.

## 15. OCR / digit verification

OCR chỉ để locate.
Số quyết định kết luận phải đọc trực tiếp từ ảnh/bản vẽ.

DV:
- DV-0: chưa kiểm ảnh
- DV-1: OCR only
- DV-2: nhìn trực tiếp
- DV-3: ảnh + checksum
- DV-4: ảnh + >=2 nguồn độc lập

Issue đỏ nên DV-3/DV-4.

## 16. Three-pass protocol — bắt buộc

### Pass 1 — Coverage / primary audit
- phủ toàn bộ phạm vi;
- dựng model;
- kiểm detail;
- summary;
- BOQ;
- calculation;
- issue;
- unresolved.

### Pass 2 — Blind independent pass
Không dùng danh sách lỗi pass 1 làm checklist chính.
Ưu tiên:
- trang không lỗi;
- dòng xanh;
- trang không bảng;
- title block/note/detail-title;
- assembly;
- phép tính lớn.

Mục tiêu: chống confirmation bias và tìm lỗi mới.

### Pass 3 — Forensic micro-detail + false-positive review
Bắt buộc sau Pass 2.

Pass 3 phải:
1. mở lại mọi issue đỏ/cam/vàng;
2. tính lại phép tính quan trọng từ evidence gốc;
3. soi từng detail nhỏ:
   - digit;
   - dấu thập phân;
   - D/L/t;
   - chiều sâu;
   - overlap;
   - lap;
   - offset;
   - hidden segment;
   - biên cong;
   - interface;
   - title/caption;
   - unit;
   - integer count;
   - subtotal/total;
4. kiểm lại detail↔summary từng dòng;
5. kiểm final BOQ row;
6. thử chứng minh issue là sai kết luận;
7. rà sample/nhóm các dòng xanh có risk cao;
8. ghi Third Pass Ledger.

Mỗi issue cuối cùng bắt buộc là:
- `CONFIRMED_ERROR`
- `UNRESOLVED`
- `FALSE_POSITIVE`
- `CLOSED_WITH_EXPLANATION`

Không giữ `CONFIRMED_ERROR` nếu Pass 3 tìm được bằng chứng bác bỏ.

## 17. False Positive Ledger

Với issue bị bác:
- issue_id;
- pass phát hiện;
- claim ban đầu;
- evidence gây nghi ngờ;
- evidence mới;
- calculation mới;
- reason for closure;
- status = FALSE_POSITIVE hoặc CLOSED_WITH_EXPLANATION;
- downstream conclusions cần thu hồi;
- annotations cần xóa;
- report cells cần đổi màu.

Bằng chứng mới phải propagate đến toàn bộ downstream.

## 18. Large project / 200 trang

Không chia batch rồi mất global context.
Phải:
1. inventory toàn bộ trước;
2. tạo global page ledger;
3. global physical model;
4. chia work packets;
5. mỗi packet trả structured ledger;
6. merge;
7. chạy global orphan check;
8. summary reconciliation toàn bộ;
9. Pass 2 cross-batch;
10. Pass 3 cross-batch + false-positive review;
11. coverage gate toàn project.

## 19. Sub-agent

Có thể dùng sub-agent, nhưng:
- agent không tự phát hành kết luận cuối;
- mọi output phải theo schema;
- cùng ID/object dictionary;
- reviewer phải kiểm conflict;
- calculation phải tái lập;
- final integrator chịu trách nhiệm Coverage Gate.

Role khuyến nghị:
- Inventory/Document-Control
- Geometry/Physical Model
- Detail Table
- Functional/Interface
- Summary/BOQ
- Calculation
- Second-pass Reviewer
- Third-pass Forensic Reviewer
- Annotation QA
- Integrator

## 20. Kết luận và màu

- 🔴 CONFIRMED_ERROR
- 🟠 INCONSISTENT / CONFLICT
- 🟡 UNRESOLVED / NEED_CONFIRMATION
- 🟢 VERIFIED
- ⚪ NOT_APPLICABLE
- 🩶 NOT_CHECKED

Không dùng xanh nếu chưa có independent check.


## 20.1. Ngôn ngữ báo cáo bắt buộc

Mặc định mọi **sản phẩm người dùng nhìn thấy** phải dùng **tiếng Việt**, trừ khi người dùng yêu cầu ngôn ngữ khác.

Áp dụng bắt buộc cho:
- tên sheet Excel;
- tiêu đề cột, nhãn KPI, trạng thái, dashboard;
- mô tả lỗi, kiến nghị, ghi chú, kết luận;
- note/leader trong PDF đánh dấu lỗi;
- tên trạng thái trong Coverage Gate / Pass review khi xuất cho người dùng;
- phần trả lời tóm tắt cuối cùng.

Các khóa nội bộ/schema/code có thể giữ tiếng Anh để máy xử lý, nhưng **không được bê nguyên nhãn nội bộ tiếng Anh ra báo cáo**.

Được phép giữ nguyên các viết tắt/tên chuẩn kỹ thuật khi cần:
`BOQ`, `FRP`, `PDF`, `CAD`, `BTCT`, `BTNC`, `UV`, `DV-3/DV-4`, mã bản vẽ, mã issue/calc, tên sản phẩm/vật liệu chính thức.

### Mapping trạng thái người dùng
- `CONFIRMED_ERROR` → `ĐÃ XÁC NHẬN SAI`
- `INCONSISTENT / CONFLICT` → `KHÔNG NHẤT QUÁN`
- `UNRESOLVED / NEED_CONFIRMATION` → `CHƯA ĐỦ CĂN CỨ / CẦN XÁC NHẬN`
- `VERIFIED` → `ĐÃ XÁC NHẬN ĐÚNG`
- `CLOSED_WITH_EXPLANATION` → `ĐÃ ĐÓNG - CÓ GIẢI THÍCH`
- `PASS` → `ĐẠT`
- `PASS WITH OPEN ITEMS` → `ĐẠT CÓ ĐIỀU KIỆN`
- `COMPLETE` → `HOÀN TẤT`

### Tên sheet Excel mặc định
Ưu tiên các tên tiếng Việt sau:
- `00_Tổng_quan`
- `01_Nhật_ký_hồ_sơ`
- `02_Mô_hình_hình_học`
- `03_Rà_soát_chi_tiết`
- `04_Đối_chiếu_tổng_hợp`
- `05_Sổ_tính_toán`
- `06_Danh_sách_lỗi`
- `07_Ma_trận_đối_chiếu`
- `08_Lượt_kiểm_thứ_ba`
- `09_Cổng_độ_phủ`
- và các sheet chuyên ngành bằng tiếng Việt.

### Language QA trước phát hành
Trước khi export Excel/PDF phải quét các nhãn tiếng Anh thường bị rò từ schema, ví dụ:
`Dashboard`, `Pass`, `Coverage Gate`, `Release`, `Reported`, `Audited`, `Status`, `Summary`, `Detail`, `Source`, `Unresolved`, `Confirmed Error`, `Downstream`, `Action`, `Evidence`, `Checked`.

Nếu còn các nhãn này trong vùng người dùng nhìn thấy mà không phải tên riêng/viết tắt kỹ thuật được phép, **Coverage Gate chưa được PASS**.

## 21. PDF Annotation QA

Tách:
- technical QA
- annotation QA

Mỗi annotation:
- annotation_id;
- issue_id;
- target_type;
- target_crop;
- pixel_bbox/anchor;
- mark_style;
- note_bbox;
- leader_endpoint;
- technical_qa_status;
- annotation_qa_status.

Không phát hành PDF nếu annotation target chưa PASS.

## 22. Excel deliverable

Tên mặc định:
`Bao_cao_<Ten_cong_trinh>.xlsx`

Tối thiểu nên có:
- 00_Dashboard
- 01_Run_Manifest
- 02_Page_Ledger
- 03_Physical_Model
- 04_Evidence_Map
- 05_Cross_View
- 06_Detail_Audit
- 07_Summary_Lineage
- 08_BOQ_Reconciliation
- 09_Calculation_Ledger
- 10_Issues
- 11_Second_Pass
- 12_Third_Pass
- 13_False_Positive
- 14_Coverage_Gate
- các sheet chuyên ngành theo dự án.

## 23. Coverage Gate trước FINAL

FINAL chỉ khi:
- page coverage đầy đủ;
- detail rows có trạng thái;
- mọi subsection bảng đã qua sequence/reset check;
- mọi dòng có đơn vị rời rạc đã qua integer sanity hoặc có giải thích;
- summary rows có lineage/status và row-by-row reconciliation;
- drawing↔BOQ orphan check hoàn tất;
- các dimension symmetry/paired geometry có ảnh hưởng quantity đã được closure;
- Pass 1 complete;
- Pass 2 complete;
- Pass 3 complete;
- issue ledger không có issue "unknown status";
- false positives đã propagate;
- calculation ledger không có công thức lỗi chưa giải thích;
- PDF annotations QA PASS;
- deliverables đã tồn tại.

Có unresolved hợp lệ thì có thể phát hành:
`ĐẠT CÓ ĐIỀU KIỆN / PARTIAL WITH OPEN ITEMS`
nhưng phải chỉ rõ.

## 24. Quy tắc cuối

> Không biết thì không đoán.

> Không đo kích thước thiếu bằng tỷ lệ hình vẽ để tạo "sự thật".

> Không xác nhận đỏ nếu chưa đủ chuỗi bằng chứng.

> Không bỏ qua một chi tiết nhỏ chỉ vì tổng cuối đang khớp.

> Không bỏ qua false positive: phát hiện sai kết luận cũng là một phần bắt buộc của audit.

> Chỉ phát hành sau 3 pass + Coverage Gate.
