# Large Project Workflow — 50–200+ Pages

## Phase 0 — Global inventory
Không chia agent trước khi:
- biết tổng file/page;
- page map toàn cục;
- revision map;
- project structure.

Keep a global page manifest before batching. Every batch must name its inclusive source-page range and return the global page IDs it processed. Before merging, prove that the union of batch ranges equals the assigned scope and that no page ID occurs twice. Reconcile per-file page counts and hashes; never release a project because all batches individually passed while a page or cross-batch interface remains unreviewed.

## Phase 1 — Partition
Chia theo:
- volume;
- bridge/structure;
- discipline;
- work package;
- summary boundary.

Không chia khiến một assembly bị tách khỏi detail/summary liên quan.

## Phase 2 — Work packet contract
Mỗi packet nhận:
- global object dictionary;
- page range;
- known interfaces;
- output schema;
- prohibited assumptions.

## Phase 3 — Merge
- merge object IDs;
- conflict detection;
- orphan detection;
- duplicate row detection;
- global calculation registry.

## Phase 4 — Global reconciliation
- all detail rows;
- all summaries;
- all BOQ rows;
- global root-cause propagation.

## Phase 5 — Three pass
Pass 2 và Pass 3 phải có cross-batch review.
Không được coi nhiều batch PASS = project PASS nếu global gate chưa chạy.

## Coverage metrics
- pages checked / total
- tables checked / total
- detail rows processed / total
- summary rows processed / total
- objects mapped
- orphan counts
- calc coverage
- pass status

## Memory and MCP support

- Search project-scoped memory and the bundled regression/reference cases for prior misses before the first pass; record consulted case IDs/titles in the run manifest.
- Turn each applicable remembered miss into a source recheck and, when it reveals a reusable failure pattern, a regression case with a counterexample/false-positive guard.
- Memory is a checklist, not evidence. Re-open the current revision and original page/row before applying a remembered lesson.
- Use MCP tools for bounded extraction, page rendering, table parsing or retrieval when available; verify tool output against the source and retain source anchors. If a tool is unavailable or degraded, log that limitation and use the available source-reading path.
- Agent agreement and repeated outputs from the same source/tool are not independent corroboration.
