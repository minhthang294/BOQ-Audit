# Sanity Gates

## 1. Discrete quantity gate
Đơn vị:
- cái
- bộ
- biển
- lỗ
- bao
- cọc
- gối
- khe
- thanh (khi đếm vật thể)

mặc định phải là số nguyên.
Nếu số lẻ:
- flag;
- kiểm conversion/measurement rule;
- chỉ chấp nhận khi hồ sơ có giải thích.

## 2. Unit gate
Kiểm:
- m vs mm
- m2 vs m3
- kg vs t
- cái vs bộ
- material quantity vs work quantity.

## 3. Magnitude gate
So order-of-magnitude với geometry.
Không kết luận sai chỉ từ sanity; dùng nó để kích hoạt kiểm sâu.

## 4. Duplicate-vector anomaly
Hai dòng khác chức năng có vector quantity giống bất thường → kiểm copy/reference.

## 5. Index/section gate
Phát hiện:
- STT lặp;
- section duplicate;
- Roman numeral duplicate;
- missing row sequence.

## 6. Symmetry / paired-dimension gate
Không tự coi trái/phải hoặc hai mép đối xứng.
Nếu hình cho hai kích thước khác nhau, kiểm từng bên.
Nếu chức năng, overall dimension, section geometry hoặc chi tiết chứng minh hai phía phải tương đương, so trực tiếp paired dimensions.
Một cặp 250/200 trong cấu tạo đối xứng phải trigger closure thay vì được bỏ qua như sai khác cục bộ.
Khi khóa một bên là typo, phải recalc toàn bộ downstream quantity phụ thuộc dimension đó.

## 7. Summary row parity gate
Mỗi row detail phải có mapping summary phù hợp và ngược lại.
So `name/spec + unit + value + scope`, không chỉ subtotal nhóm.

## 8. Spec thickness gate
Các vật liệu lớp/tấm/FRP phải so chiều dày giữa mọi nguồn.
Ví dụ 0,635 mm ở detail nhưng 1,3 mm ở summary phải flag `MISMATCH_NAME_SPEC` ngay cả khi area bằng nhau.

## 9. Reset-aware index sequence gate
Trong một subsection, STT phải liên tục theo rule.
Reset chỉ hợp lệ tại section/header mới.
Duplicate 5,6 rồi tiếp tục 7..11 không được coi chỉ có 2 ô sai: toàn chuỗi sau duplicate phải được kiểm expected index.


## v6.3 gates
### Assumption gate
Mọi MODEL_ASSUMPTION chi phối quantity phải có trạng thái open/closed và sensitivity.

### Reconciliation gate
Mọi back-solve phải gắn RECONCILIATION_ONLY; không được coi là takeoff độc lập.

### Paired-side gate
Cấu kiện hai bên phải có side A/B evidence riêng.

### Scope-overlap gate
Kiểm component/work-item lineage để bắt cộng trùng.

### Target-fit gate
Nếu mô hình thay đổi sau khi nhìn target, Pass 3 phải tái dựng lại bằng blind geometry model trước khi release.
