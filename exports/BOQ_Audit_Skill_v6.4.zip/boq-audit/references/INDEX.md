# Reference Index — BOQ Audit v6.4

## Core — luôn đọc
1. `evidence.md`
2. `data-and-delivery.md`
3. `report-language.md`
4. `detail-table-audit.md`
5. `functional-closure.md`
6. `summary-reconciliation.md`
7. `three-pass-protocol.md`
8. `anti-false-positive.md`
9. `sanity-gates.md`
10. `geometry-assumption-control.md`

## Theo tình huống
11. `takeoff.md`
12. `estimating.md`
13. `document-control.md`
14. `structured-data.md`
15. `large-project-workflow.md`
16. `sub-agents.md`
17. `pdf-annotation-qa.md`
18. `drawing-auditability.md`
19. `regression.md`
20. `reference-cases.md`

Mỗi reference là một phần của protocol. Không được coi references là "đọc thêm tùy chọn"
khi `SKILL.md` chỉ định file đó là bắt buộc.

## Thực thi / khôi phục phiên

Đọc `execution-workflow.md` khi bắt đầu, tiếp tục hoặc sửa dữ liệu trong audit; dùng `codex-execution.md` cho JSON và lệnh. `regression.md` và `reference-cases.md` bắt buộc trước Pass 1 để lập checklist có bằng chứng.
