# Evidence and Source Hierarchy

## 1. Loại bằng chứng
- hình học có dimension;
- leader/callout;
- mặt bằng/mặt cắt/chi tiết;
- title/detail title/caption;
- note kỹ thuật;
- quantity table;
- summary table;
- BOQ/estimate;
- revision/change note;
- user-confirmed engineering fact.

## 2. Nguyên tắc
- BOQ không phải ground truth.
- OCR không phải bằng chứng cuối.
- Không lấy số suy ngược từ total để chứng minh geometry.
- Một view copy từ view khác không phải independent evidence.
- User confirmation phải lưu rõ phạm vi và không tự áp sang cấu kiện khác.

## 3. Evidence anchor
Mỗi biến quan trọng nên có:
- page;
- printed sheet;
- view/detail ID;
- target description;
- DV level;
- source type.

## 4. Thiếu bằng chứng
Gắn:
`UNRESOLVED / EVIDENCE_GAP`

Không:
- đoán từ pattern;
- đo từ tỷ lệ hình;
- tự bù cho khớp bảng.


## 5. Evidence class — v6.3
Mỗi input quan trọng phải gắn một trong: `OBSERVED / DERIVED / USER_CLAIM / MODEL_ASSUMPTION / RECONCILIATION`.

- User claim không override drawing nếu chưa cross-view.
- Reconciliation không phải independent evidence.
- Model assumption phải có reason + sensitivity + closure status.
