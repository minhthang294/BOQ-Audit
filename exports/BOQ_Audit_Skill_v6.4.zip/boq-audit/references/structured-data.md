# Structured Data Contract

## ID convention
- PAGE-###
- OBJ-...
- INST-...
- ROW-...
- SUM-...
- BOQ-...
- CALC-...
- ISS-...
- ANN-...
- PASS2-...
- PASS3-...

## Required cross-links
- issue → object
- issue → evidence
- issue → calc
- detail row → summary row
- summary row → BOQ row
- annotation → issue
- pass review → issue/calc

## Status vocabulary
- VERIFIED
- CONFIRMED_ERROR
- INCONSISTENT
- UNRESOLVED
- FALSE_POSITIVE
- CLOSED_WITH_EXPLANATION
- NOT_APPLICABLE
- NOT_CHECKED

## Data preservation
Lưu raw input trước rounding.
Lưu đơn vị tại từng biến.
Không overwrite kết quả pass trước; giữ history.


## Assumption Ledger — v6.3
Bắt buộc với hồ sơ có geometry không khóa hoàn toàn. Trường tối thiểu:
`assumption_id, object_id, variable, value, unit, evidence_class, source_anchor, rationale, sensitivity, affects_qty, status, closure_evidence`.

`evidence_class`: OBSERVED / DERIVED / USER_CLAIM / MODEL_ASSUMPTION / RECONCILIATION.
