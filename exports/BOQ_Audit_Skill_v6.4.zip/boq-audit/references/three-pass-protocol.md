# Three-Pass Protocol — v6.3

## PASS 1 — Primary Coverage Audit
Mục tiêu:
- phủ toàn bộ hồ sơ;
- dựng model;
- kiểm detail/summary/BOQ;
- tạo issues/calcs;
- gắn unresolved.

Output:
- `pass1_complete`
- issue list v1
- calculation ledger v1
- coverage snapshot v1

## PASS 2 — Blind Independent Recalculation
Không dùng issue list pass 1 làm checklist chính.

Thứ tự khuyến nghị:
1. summary → detail
2. các dòng xanh
3. trang không lỗi
4. trang không bảng
5. title/caption/note
6. physical assembly
7. phép tính lớn

Mục tiêu:
- tìm lỗi pass 1 bỏ sót;
- kiểm anti-confirmation;
- tạo independent calc.

Output:
- new issues;
- confirmed issues;
- disputed issues;
- `second_pass = PASS/OPEN`.

## PASS 3 — Forensic Micro-Detail + False Positive Closure

### A. Micro-detail sweep
Rà:
- digit 8/6, 1/7, dấu thập phân;
- mm/m;
- m2/m3;
- D/L/t;
- 160/200;
- 1,0/1,3 mm;
- overlap/lap;
- 100/200/250;
- hidden offset;
- count integer;
- subtotals;
- labels;
- leader endpoint;
- title/detail-title;
- section/STT/index + continuity/reset boundary;
- detail↔summary row parity;
- discrete integer units;
- FRP/material thickness;
- symmetry/paired geometry + downstream recalculation;
- user-claim anchoring;
- geometry assumptions;
- back-solve/reconciliation masquerading as takeoff;
- scope overlap/double counting;
- target-fitting to BOQ/Excel.

### B. Recalculate
Tính lại các `CALC-*` quan trọng bằng đầu vào gốc.
Không copy kết quả Pass 2.

### C. Re-open issues
Mỗi issue phải bị thử bác bỏ:
- có revision khác?
- có lap/overlap?
- có dimension functional?
- có một view/chi tiết nhỏ giải thích chênh?
- có loại quantity khác?
- có rounding thật?
- có missing sheet?
- có parent geometry khác?
- có phải kết luận đang dựa vào USER_CLAIM?
- có MODEL_ASSUMPTION chưa khóa?
- có RECONCILIATION được dùng như evidence độc lập?
- có side A/B bị nhân 2 máy móc?
- có component khác đang bị cộng trùng?

### D. Final issue states
- CONFIRMED_ERROR
- UNRESOLVED
- FALSE_POSITIVE
- CLOSED_WITH_EXPLANATION

### E. Propagation
Nếu false positive:
- thu hồi annotation;
- đổi report status;
- sửa dashboard count;
- sửa downstream;
- ghi lịch sử.

## Release condition
Không FINAL nếu thiếu pass 3.
