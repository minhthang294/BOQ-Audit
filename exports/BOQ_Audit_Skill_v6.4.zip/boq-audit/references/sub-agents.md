# Optional Sub-Agent Architecture

## Roles

### 1. Inventory / Document Control Agent
Output: page ledger, revision map, section/index anomalies.

### 2. Geometry / Physical Model Agent
Output: object dictionary, instances, counts.

### 3. Evidence / Cross-view Agent
Output: anchors, view consistency.

### 4. Detail Table Agent
Output: row-by-row audit.

### 5. Functional / Interface Agent
Output: work-chain, geometric union, interface checks.

### 6. Summary / BOQ Agent
Output: summary lineage, two-way reconciliation.

### 7. Calculation Agent
Output: rerunnable CALC IDs.

### 8. Second-pass Reviewer
Blind independent review.

### 9. Third-pass Forensic Reviewer
Micro-detail + false-positive challenge.

### 10. Annotation QA Agent
Only annotation positioning/visual QA.

### 11. Integrator
Merges ledgers, resolves conflicts, runs Coverage Gate.

## Rules
- Agent output must be structured.
- Không cho agent infer missing dimensions from BOQ.
- Conflict between agents remains OPEN until evidence resolves.
- Agent count does not equal independent evidence count.
