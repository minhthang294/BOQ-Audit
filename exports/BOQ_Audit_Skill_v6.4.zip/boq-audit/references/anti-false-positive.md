# Anti-False-Positive Protocol

Trước khi giữ một lỗi đỏ:

- đúng cùng physical object?
- đúng cùng phạm vi?
- đúng revision?
- leader chạm đúng object?
- detail title có tham số bổ sung?
- có lap/overlap?
- có dimension chain?
- có functional reason?
- có quantity type khác nhau?
- có rounding policy?
- có đơn vị conversion?
- có user-confirmed value?
- có source sheet còn thiếu?
- có thể bảng đúng nhưng một callout drafting sai?
- có thể callout đúng nhưng mapping sai object?

## Rule
Một issue bị bằng chứng mới bác bỏ phải được đóng.
Không "bảo vệ" kết luận cũ.

## False Positive Ledger
Lưu:
- original claim
- evidence used
- new evidence
- new calc
- closure reason
- affected annotations/reports


## Anti-anchoring / anti-target-fit — v6.3
Trước khi giữ một kết luận xanh hoặc đỏ, hỏi thêm:
- input nào đến từ lời người dùng thay vì bản vẽ?
- có giả thiết geometry nào chưa được dimension khóa?
- có phép back-solve từ BOQ/Excel không?
- mô hình có được chỉnh để target khớp không?
- có scope overlap/cộng trùng giữa component và work item khác không?
- side A/B đã được đọc riêng chưa?

Nếu câu trả lời có rủi ro, hạ trạng thái về UNRESOLVED và mở evidence gap.
