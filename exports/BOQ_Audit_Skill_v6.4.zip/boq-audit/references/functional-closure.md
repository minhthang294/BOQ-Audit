# Functional Closure

## Functional geometry chain
Cho mỗi cấu kiện/công tác:
`where installed → what must be covered/contacted/anchored → controlling dimension → quantity`

## Parent/child work-chain
Ví dụ:
`repair footprint → surface prep → mortar/epoxy → FRP/coating`

Công tác phụ phải bám parent geometry, không chỉ copy số.

## Geometric union
Với chuẩn bị bề mặt cho nhiều lớp:
- dùng hợp footprint cần xử lý;
- không cộng chồng hai lần;
- phần lớp nhỏ nằm trong lớp lớn không tăng prep area;
- chỉ cộng phần vượt.

## Interface compatibility
Kiểm:
- D_hole > D_bar;
- khe đủ cho keo/dung sai;
- plate footprint;
- gutter width vs joint width;
- wrap length vs circumference + lap.

## Dimension-chain reconstruction
Không tin `L=` đơn lẻ nếu cấu kiện đi qua nhiều đoạn.
Cộng lại end/middle/offset/lap/anchor từ geometry.


## Symmetry closure — v6.2
Với cấu kiện hai bên/paired geometry:
1. xác định có thật sự đối xứng theo thiết kế/chức năng không;
2. nếu có, pair các dimension tương ứng;
3. kiểm overall dimension và các chi tiết phụ để xác định bên nào sai;
4. không lấy một dimension sai làm input cho bảng;
5. sau correction, dựng lại mọi bar length / surface / volume / weld / plate / tube có dependency.

Canonical pattern: mặt cắt gờ lan can hai bên tương đương nhưng một bên 250 và một bên 200. Nếu overall + detail chứng minh 200 là canonical, dimension 250 là drafting error và bảng thép dựa trên geometry cũ phải được tính lại.


## Paired-side instance closure — v6.3
Không chỉ kiểm symmetry của dimension; phải lưu hai physical instances riêng trước khi gộp.
Nếu side A=5991 và side B=5990 thì tổng dùng 5991+5990, không `5991×2`.

## Complex-profile closure
Với wave/curved/cutout geometry, functional appearance không đủ để xác định mathematical primitive. Hình trông như cung tròn không đồng nghĩa là cung tròn. Chỉ khóa khi có dimension/model evidence.
