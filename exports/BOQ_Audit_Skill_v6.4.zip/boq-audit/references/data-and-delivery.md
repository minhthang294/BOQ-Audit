# Data and Delivery

## Structured ledgers tối thiểu
- Run Manifest
- Page Ledger
- Document Control Ledger
- Physical Model
- Physical Instance Ledger
- Evidence Map
- Cross-view Matrix
- Detail Audit Ledger
- Summary Lineage Ledger
- BOQ Reconciliation Ledger
- Calculation Ledger
- Issue Ledger
- Second Pass Ledger
- Third Pass Ledger
- False Positive Ledger
- Coverage Gate
- Annotation QA Ledger

## Mỗi kết luận phải truy được
`final conclusion`
→ `issue/calc ID`
→ `object/work item`
→ `drawing anchor`
→ `source page/detail`

## Deliverables
### Excel
Tên:
`Bao_cao_<Ten_cong_trinh>.xlsx`

### PDF
Tên:
`Ban_ve_<Ten_cong_trinh>_Danh_dau_loi.pdf`

PDF phải đánh dấu trực tiếp trên trang gốc, không chèn trang "báo cáo lỗi" thay cho annotation.

## Số thập phân
Báo cáo tiếng Việt có thể hiển thị dấu phẩy thập phân, nhưng calculation engine phải lưu numeric values chuẩn.


## Ngôn ngữ deliverable
Mặc định Excel, PDF annotation và tóm tắt phát hành phải dùng tiếng Việt.
Không dùng trực tiếp tên ledger/schema tiếng Anh làm tên sheet hoặc tiêu đề cột người dùng nhìn thấy.
Trước phát hành phải chạy Language QA theo `references/report-language.md`.
