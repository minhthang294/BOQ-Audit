# BOQ Audit v6.2.1

Bộ skill dùng cho rà soát bản vẽ, bóc tách khối lượng, kiểm BOQ và hỗ trợ kiểm dự toán
cầu / công trình giao thông.

## Điểm cốt lõi của v6.2.1

- Bản vẽ và hồ sơ kỹ thuật là bằng chứng; BOQ là đối tượng cần kiểm.
- Dựng mô hình vật lý trước khi so số BOQ.
- Kiểm 100% dòng trong phạm vi đã nhận.
- Kiểm hai chiều `Drawing ↔ Detail Table ↔ Summary ↔ BOQ ↔ Estimate`.
- Mọi phép tính quan trọng phải có `CALC-ID`, đầu vào, đơn vị, nguồn và có thể chạy lại.
- Có `Coverage Gate` trước phát hành.
- Bắt buộc chạy **3 pass**:
  1. First Pass — audit chính và phủ toàn bộ phạm vi.
  2. Second Pass — blind independent recalculation / anti-confirmation.
  3. Third Pass — forensic micro-detail review + false-positive closure.
- Không giữ một lỗi chỉ vì pass trước đã gắn cờ.
- Nếu thiếu bằng chứng hình học: ghi `CẦN XÁC NHẬN / KHÔNG ĐỦ BẰNG CHỨNG`, không đoán theo tỷ lệ hình vẽ.
- PDF đánh dấu chỉ phát hành khi annotation QA đạt.

- Sequence gate có nhận biết reset: không chỉ bắt STT lặp mà kiểm expected index cho toàn subsection.
- Row-by-row detail↔summary parity: name/spec/unit/value/scope đều phải khớp.
- Discrete quantity gate mạnh hơn cho `cái/bộ/biển/lỗ/cọc...`.
- FRP spec gate: loại sợi và chiều dày được audit độc lập.
- Symmetry/paired-geometry closure và downstream recalculation khi một dimension gốc thay đổi.

## Cấu trúc gói

- `SKILL.md`: prompt/skill chính.
- `references/`: toàn bộ tài liệu tham chiếu bắt buộc và module chuyên môn.
- `schemas/`: schema dữ liệu có cấu trúc cho ledgers.
- `templates/`: CSV/JSON mẫu để agent tạo dữ liệu.
- `legacy/`: bản skill cũ để truy lịch sử phát triển.
- `PACKAGE_MANIFEST.txt`: checksum SHA-256 để kiểm gói đủ file.

## Cách dùng

Khi chạy audit:
1. Đọc `SKILL.md`.
2. Đọc tối thiểu các file được chỉ định trong mục "Reference loading policy".
3. Tạo Run Manifest.
4. Chạy First Pass → Second Pass → Third Pass.
5. Chỉ phát hành sau Coverage Gate.


## Ngôn ngữ báo cáo
Mặc định mọi deliverable người dùng nhìn thấy phải bằng tiếng Việt; schema nội bộ có thể giữ key tiếng Anh. Trước export bắt buộc Language QA.
