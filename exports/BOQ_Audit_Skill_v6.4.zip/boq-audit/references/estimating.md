# Estimating Audit

Chỉ audit giá sau khi quantity có trạng thái rõ.

## Phân lớp
- quantity error
- spec error
- unit-rate error
- source-price issue
- norm/code issue
- formula/link issue

## Excel estimate
Scan:
- #REF!
- #DIV/0!
- #VALUE!
- #NAME?
- #N/A

Kiểm:
- sheet links;
- named ranges;
- material prices;
- price date/source;
- labor/fuel;
- transport;
- subtotal;
- project total.

Không sửa final cost trước khi khóa root cause quantity/spec.
