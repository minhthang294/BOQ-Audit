# Document Control

## Page identity ledger
Mỗi trang:
- PDF page
- printed sheet
- project
- owner
- location
- drawing title
- drawing no.
- revision
- issue date
- discipline
- page type

## Uniqueness checks
- drawing number uniqueness;
- sheet number uniqueness;
- STT uniqueness;
- section numbering;
- Roman numeral sequence;
- duplicated headings;
- copy/paste title blocks.

## Rule
Document-control issue độc lập với quantity issue.
Một title block sai không tự chứng minh quantity sai, nhưng phải được báo.


## Sequence continuity — v6.2
Uniqueness không đủ. Phải kiểm continuity có nhận biết reset:
- trong một subsection, index phải theo rule liên tục;
- reset chỉ hợp lệ khi có header/section boundary rõ;
- duplicate ở giữa subsection làm mọi index sau đó đáng ngờ, kể cả không còn duplicate;
- phải ghi cả `reported_index` và `expected_index`;
- row count phải khớp expected final index nếu rule là 1..N.

Phân biệt:
- `DUPLICATE_INDEX`
- `MISSING_INDEX`
- `SEQUENCE_SHIFT`
- `VALID_SECTION_RESET`
- `ROMAN_SECTION_DUPLICATE`
