# Summary Reconciliation Gate

## Bắt buộc
Sau detail audit, xác định tất cả summary table/page.

## Mỗi summary row lưu
- summary page;
- section;
- row;
- name/spec;
- unit;
- source pages;
- source table rows;
- aggregation rule;
- reported total;
- audited total;
- delta;
- status.

## Kiểm từng dòng
Không chỉ nói "nhóm khớp".
So:
1. name/spec
2. unit
3. value
4. scope
5. revision

## Hai chiều
### Detail → Summary
Mọi subtotal/detail quantity phải xuất hiện đúng nơi hoặc có giải thích.

### Summary → Detail
Mọi summary row phải có nguồn.

## Trạng thái đặc biệt
- ORPHAN_SUMMARY_ROW
- MISSING_SUMMARY_MAPPING
- MISMATCH_NAME_SPEC
- MISMATCH_UNIT
- MISMATCH_VALUE
- OPEN_SOURCE

## Root cause propagation
Một lỗi gốc chỉ đếm một lần.
Delta downstream liên kết về root issue, không cộng lặp.


## Row parity + discrete sanity — v6.2
Mỗi mapping detail↔summary phải có:
- `detail_row_id`;
- `summary_row_id`;
- name/spec match;
- unit match;
- reported detail value;
- reported summary value;
- audited value;
- delta;
- status.

Không được đóng `OK` chỉ vì subtotal nhóm khớp.
Nếu đơn vị summary là `cái/bộ/biển/lỗ/cọc/...` mà quantity lẻ, phải kiểm nguồn detail và aggregation trước khi chấp nhận.
Nếu spec khác nhau (ví dụ 0,635 mm ↔ 1,3 mm), trạng thái phải là `MISMATCH_NAME_SPEC` dù value bằng nhau.


## Anti-circular reconciliation — v6.3
Reconciliation được phép để:
- phát hiện orphan;
- checksum tổng;
- tìm phạm vi chênh.

Không được dùng phép `reported total - known components` làm independent quantity cho component thiếu rồi dùng chính tổng mới để chứng minh reported total đúng. Gắn `RECONCILIATION_ONLY`.
