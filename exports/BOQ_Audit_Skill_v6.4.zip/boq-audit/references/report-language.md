# Ngôn ngữ báo cáo / Report Language QA

## Mặc định
Mọi deliverable người dùng nhìn thấy phải bằng tiếng Việt nếu người dùng không yêu cầu ngôn ngữ khác.

## Không trộn schema nội bộ vào báo cáo
Các field nội bộ như `status`, `reported_total`, `audited_total`, `pass3_result` có thể tồn tại trong JSON/CSV/schema, nhưng khi render Excel/PDF phải ánh xạ sang nhãn tiếng Việt.

## Mapping bắt buộc
- Dashboard → Tổng quan
- Run Manifest → Nhật ký chạy / thông tin lần rà soát
- Page Ledger → Nhật ký trang
- Geometry Model → Mô hình hình học
- Detail Audit → Rà soát chi tiết
- Summary Reconciliation → Đối chiếu tổng hợp
- Calculation Ledger → Sổ tính toán
- Issue Ledger → Danh sách lỗi
- Cross View → Ma trận đối chiếu
- Third Pass → Lượt kiểm thứ ba
- Coverage Gate → Cổng kiểm soát độ phủ
- Reported → Theo bảng
- Audited/Correct → Theo kiểm tra / Giá trị đúng
- Status → Trạng thái
- Evidence → Bằng chứng
- Action/Recommendation → Kiến nghị

## Từ được phép giữ nguyên
BOQ, FRP, PDF, CAD, BTCT, BTNC, UV, DV, ID kỹ thuật, mã bản vẽ, mã issue/calc, tên sản phẩm/vật liệu chính thức.

## Pre-release scan
Trước export, scan workbook/PDF note để tìm các từ tiếng Anh rò rỉ. Nếu còn nhãn UI/report tiếng Anh chưa được phép thì phải sửa trước khi phát hành.
