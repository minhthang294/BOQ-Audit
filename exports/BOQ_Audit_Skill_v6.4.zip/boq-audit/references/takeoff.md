# Takeoff Rules

## Thép
Mỗi dòng:
shape, D, L, qty, total length, kg/m, kg.
Kiểm subtotal theo D và total.

Thép tròn kiểm nhanh:
`kg/m ≈ d²/162`

## Bê tông / vữa
Đếm object trước, rồi volume/object.
Không lấy tổng mét dài cột nhân thể tích móng đơn vị.

## FRP / carbon / lưới
Dựng:
- gross;
- openings;
- cutouts;
- laps;
- overlaps;
- layers;
- net;
- number of faces;
- repeats.

Không dùng `kg / unit weight` làm bằng chứng area cuối.

## Khoan / neo / keo
Kiểm chuỗi:
hole D/depth/qty → bar → adhesive → rate/BOQ.

Ví dụ volume keo:
`V = π/4 × (D_hole² - D_bar²) × L × N`

## Temporary works
Tách:
- fabricated sets;
- concurrent sets;
- installation cycles;
- dismantling cycles;
- reuse.


## Hình học thép tấm/profile phức tạp — v6.3
- Tấm có lỗ xiên/biên cong/sóng: tính area net chỉ khi geometry được dimension đủ.
- Không thay lỗ xiên bằng rectangle chỉ vì có width/height cục bộ.
- Không coi đường cong là circular arc nếu drawing không xác nhận radius/chord+sagitta/center.
- Nếu dùng mô hình gần đúng: status = `ASSUMPTION_ONLY`, không dùng để khóa BOQ.
- Mọi tấm chạy hai bên: tính side A/B riêng rồi cộng.

## Scope partition trước cộng tổng
Mỗi component phải map đúng work item/BOQ row. Cấm cộng trùng giữa fabricated assembly và reinforcement/temporary/accessory items đã tách riêng.
