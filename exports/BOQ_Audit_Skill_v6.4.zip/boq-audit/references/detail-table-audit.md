# Detail Table Audit

## 100% row rule
Nếu bảng có N dòng, xử lý N/N dòng.
"Dòng không đủ căn cứ" vẫn tính là đã xử lý nếu đã gán trạng thái OPEN/YELLOW và lý do.

## Checklist từng dòng
- row ID / STT
- tên
- material/spec
- D/L/B/H/t
- qty
- factor side/span/layer
- unit
- unit weight
- formula
- raw quantity
- rounded quantity
- subtotal impact
- summary mapping
- BOQ mapping
- downstream estimate impact
- evidence anchor
- DV level
- status

## Không chỉ kiểm số
Tên dòng là dữ liệu kỹ thuật.
Ví dụ `D18 L=160mm` phải kiểm cả D và L.

## Section/STT uniqueness
Phải phát hiện:
- STT lặp;
- section lặp;
- Roman numeral dùng lại sai;
- row copy-paste sang nhầm section;
- dòng thiếu do nhảy số.

STT lặp không tự chứng minh quantity sai, nhưng là document-control issue và có thể chỉ ra copy/paste.


## Reset-aware sequence gate — v6.2
Không chỉ tìm STT lặp. Với từng subsection:
1. xác định boundary bắt đầu/kết thúc;
2. xác định rule đánh số (`1..N`, Roman, hoặc custom);
3. cho phép reset chỉ tại boundary/header rõ ràng;
4. kiểm `duplicate / missing / jump / rollback`;
5. nếu duplicate xuất hiện, tính lại expected index cho mọi row phía sau;
6. so số row vật lý với expected final index để bắt dòng thiếu.

Ví dụ canonical SCAN0775 — Cấu tạo tay vịn lan can (3/3):
- Nhóm I, nhịp 10 m hiện có `1,2,3,4,5,6,5,6,7,8,9,10,11`;
- đúng phải là `1..13`: F1=7, F1'=8, O2=9, O2'=10, B1=11, B2=12, H=13;
- nhóm I, nhịp 8 m lặp đúng cùng lỗi và cũng phải sửa thành `1..13`.
- reset I/II/III/IV khi sang header nhịp 8 m là reset hợp lệ vì có subsection mới.

## Geometry correction propagation
Nếu một kích thước gốc được sửa:
- invalidate mọi dòng quantity phụ thuộc;
- dựng lại bar/plate/tube/weld length từ geometry;
- tính lại subtotal/total;
- chạy lại summary reconciliation và downstream estimate.
Không được chỉ sửa note/dimension rồi giữ nguyên bảng cũ.
