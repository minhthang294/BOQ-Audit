# PDF Annotation QA v4 — đánh dấu chính xác, ghi chú trên trang

Áp dụng cho mọi PDF bàn giao có đánh dấu. Đánh dấu lệch hoặc ghi chú khó đọc là lỗi bàn giao.

## 1. Chốt đúng mục tiêu

Mỗi lỗi phải ghi rõ trang và mục tiêu: trích số/chữ, dòng-cột, kích thước/leader hoặc ranh giới cấu kiện. Đánh dấu span nhỏ nhất chứng minh lỗi; mỗi mục tiêu riêng một mark. Không khoanh cả bảng, hình chiếu hay trang nếu lỗi chỉ nằm ở một số hoặc dòng.

Dùng `page.search_for()`/text span để tìm khi text layer đáng tin, rồi đối chiếu ảnh render. Với bản scan, trang xoay hoặc text layer lỗi, xác định khung trên ảnh render từ 300 dpi (tăng khi chữ nhỏ); pixel bbox trên ảnh là chuẩn. OCR chỉ giúp tìm, không xác nhận vị trí.

## 2. Đặt mark đúng tọa độ

Không ước lượng theo phần trăm trang. Ghi lại số trang, DPI, kích thước ảnh, pixel bbox `(x0,y0,x1,y1)`, crop origin nếu có; ghi cropbox/rotation và phép đổi sang PDF bbox. Áp dụng transform đúng một lần.

Trước khi đánh dấu trang, kiểm transform bằng bốn góc trang và một mục tiêu chữ đã biết; render overlay thử để xác nhận. Sau khi xuất PDF, render lại và xem từng crop ở mức đọc được. Viền phải ôm mục tiêu với lề hẹp, không lấn dòng kề, không che nội dung. Nếu không xác định chắc tọa độ, ghi `ANNOTATION_UNVERIFIED`; không đoán và không tính PASS.

Ưu tiên gạch chân/viền mảnh cho số hoặc dòng ngắn; chỉ khoanh ô khi cả ô là mục tiêu. Dùng viền không tô đặc, nét khoảng 0.6–0.8 pt. Tách mark cho các mục tiêu gần nhau.

## 3. Ghi chú trực tiếp lên PDF — không dùng comment popup

Mỗi mark phải có ghi chú nhìn thấy ngay trên trang, nối tới đúng mục tiêu bằng leader mảnh cùng màu. Đặt ghi chú ở lề hoặc khoảng trống gần nhất; đầu leader chạm đúng mark. Không che số liệu, chữ, kích thước hay cấu kiện. Chọn leader ngắn nhất đi qua khoảng trắng; không kéo chéo qua hàng/cột hoặc chi tiết không liên quan. Nếu đường thẳng cắt chữ hay hình, dời note hoặc đi gấp khúc theo lề trống; nếu không tìm được đường sạch, để `UNVERIFIED`, không tính `PASS`. Với mục tiêu trong bảng, leader chỉ đi vào đúng dòng mục tiêu và tránh chữ ở dòng kề. Không tạo sticky note, popup comment hoặc comment annotation; trường comment/popup để trống.

Nội dung tiếng Việt, ngắn và đủ hành động, tối đa khoảng 2 dòng: `HIGH · I-07 — Sai: [điểm sai]. Kiểm tra: [việc cần làm].` Ghi đúng mức độ và issue ID; không chỉ dùng màu để truyền mức độ. Chữ phải đọc được ở mức xem thông thường. Dùng nền trắng mờ/đục nhẹ nếu cần tăng tương phản, không phủ lên nguồn. Nếu chỗ trống gần mục tiêu không đủ, chuyển ghi chú ra lề cùng trang và dùng leader; không thu chữ đến mức khó đọc.

## 4. Màu mức độ

Dùng cùng màu cho viền/underline, leader và viền hoặc chữ ghi chú. Giữ nguyên mức độ trong issue ledger:

| Mức độ | Màu | RGB cho PDF API |
|---|---|---|
| `CRITICAL` | Đỏ sẫm `#C00000` | `(0.753, 0.000, 0.000)` |
| `HIGH` | Đỏ `#E53935` | `(0.898, 0.224, 0.208)` |
| `MEDIUM` | Cam `#ED7D31` | `(0.929, 0.490, 0.192)` |
| `LOW` | Xanh dương `#4472C4` | `(0.267, 0.447, 0.769)` |
| `NOTE` / cần chú ý | Xanh ngọc `#00A6A6` | `(0.000, 0.651, 0.651)` |

Màu chỉ bổ trợ chữ mức độ; không tự đổi mức độ để chọn màu.

## 5. Ledger và kiểm cuối

Mỗi mark một dòng Annotation QA ledger, gồm: issue ID, mức độ, file/trang, mô tả mục tiêu, pixel bbox và hệ tọa độ, transform, bbox mark, nội dung và bbox ghi chú, điểm đầu-cuối leader, crop đã xem và trạng thái `PASS`/`FAIL`/`UNVERIFIED`.

Chỉ ghi `PASS` khi: (1) mark ôm đúng mục tiêu với lề hẹp; (2) ghi chú đọc được, đúng lỗi/mức độ/việc cần làm và leader trỏ đúng mark; (3) màu mark, leader và ghi chú khớp mức độ; (4) không che nội dung và không có popup comment; (5) đã xem crop sau lần render cuối. Xem riêng từng target crop và note crop, rồi kiểm trang đầy đủ để phát hiện leader đi xuyên nội dung hoặc mark bị cắt ở mép crop. Contact sheet không thay thế việc xem từng crop; pixel/darkness score cũng không thay thế kiểm tra trực quan phần nền dưới note và toàn đường leader. Sửa lỗi hoặc false positive thì cập nhật ledger và render/xem lại trang liên quan.

## 6. Cổng phát hành

`annotation_qa_pass_count` phải bằng `annotation_target_count`; không để `FAIL` hoặc `UNVERIFIED` dưới dạng đã xác minh. Mục tiêu chưa đặt chắc phải nêu trong báo cáo và giữ trạng thái partial/blocked. Audit kỹ thuật đạt không thay thế cổng QA đánh dấu.
