# Geometry Assumption Control & Anti-Anchoring — v6.3

## 1. Mục tiêu
Ngăn auditor bị neo theo:
- con số BOQ/Excel;
- mô tả của người dùng;
- hình dạng nhìn "có vẻ" đúng trên raster;
- một mô hình toán học thuận tiện nhưng chưa được bản vẽ chứng minh.

## 2. Phân loại đầu vào
Mỗi biến hình học/quantity quan trọng phải có `evidence_class`:
- `OBSERVED`: dimension/callout/leader đọc trực tiếp.
- `DERIVED`: suy ra duy nhất từ các OBSERVED đã khóa.
- `USER_CLAIM`: thông tin người dùng nói/đính chính.
- `MODEL_ASSUMPTION`: giả thiết do auditor dựng.
- `RECONCILIATION`: giá trị suy ngược từ target/BOQ/summary.

`OBSERVED`/`DERIVED` mới được dùng làm nền cho independent takeoff.

## 3. User claim rule
User confirmation là evidence phụ, không thay thế drawing evidence.
Khi user nói một chi tiết là tấm thẳng, dày X, đối xứng... phải:
1. mở lại leader;
2. mở mặt cắt;
3. mở mặt bằng;
4. mở detail/module;
5. xác nhận scope;
6. mới cập nhật model.

Nếu user claim xung đột bản vẽ, giữ `CONFLICT` và nêu rõ.

## 4. No target-fitting
Cấm:
`BOQ target - known parts = missing part` rồi gọi missing part là bóc độc lập.
Phép đó chỉ là `RECONCILIATION`.

Một mô hình geometry được thay đổi cho tới khi khớp target là target-fitting. Không dùng độ khớp đó để xác nhận target.

## 5. Complex geometry rule
Với:
- lỗ xiên/trapezoid;
- tấm sóng/răng;
- biên cong;
- polyline bất quy tắc;
- bo góc/fillet;
- cutout/opening;
- profile đặc biệt;

không được tự thay bằng rectangle/triangle/circular segment nếu drawing không xác nhận model.
Nếu chỉ có raster thiếu dimension:
- ghi `UNRESOLVED_GEOMETRY`;
- yêu cầu CAD/vector hoặc kích thước bổ sung;
- có thể làm sensitivity/sanity-check nhưng không chốt xanh.

## 6. Paired-side closure
Mọi cấu kiện hai bên phải có:
`side_A_value`, `side_B_value`, `side_A_evidence`, `side_B_evidence`.
Không tự `×2`. Nếu hai bên lệch 1 mm vẫn ghi riêng rồi mới cộng.

## 7. Scope partition / no-double-count
Trước tổng hợp, lập scope map:
`physical assembly → subcomponent → work item → BOQ row`.

Ví dụ khe co giãn:
- thân/bộ khe;
- thép bổ sung quanh khe;
- máng inox;
- bê tông/vữa;
- ván khuôn;
- keo/vít;
- lắp đặt/NDT.

Không được lấy khối lượng nhóm A làm component của nhóm B nếu BOQ tách riêng.

## 8. Independent takeoff vs reconciliation
Report phải tách rõ:
- `INDEPENDENT_TAKEOFF`: chỉ từ OBSERVED/DERIVED.
- `RECONCILIATION_CHECK`: dùng target để kiểm tổng.
- `SENSITIVITY_CHECK`: dùng giả thiết để kiểm biên.

Không được ghi “đã xác nhận đúng độc lập” nếu quantity chủ chốt vẫn dựa vào RECONCILIATION hoặc MODEL_ASSUMPTION.

## 9. Release rule
Nếu một assumption ảnh hưởng đáng kể đến kết luận:
- status không được `ĐÃ XÁC NHẬN ĐÚNG/SAI`;
- dùng `CHƯA ĐỦ CĂN CỨ / CẦN XÁC NHẬN`;
- nêu chính xác dữ liệu còn thiếu.
