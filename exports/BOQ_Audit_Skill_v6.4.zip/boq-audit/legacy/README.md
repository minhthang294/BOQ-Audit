# Legacy

`BOQ_Audit_Skill_v5.8.md` được giữ để truy lịch sử phát triển.
v6.2 không thay thế bằng cách xóa các nguyên tắc v5.8; nó kế thừa và mở rộng,
đặc biệt với workflow dữ liệu có cấu trúc, Coverage Gate và Third Pass.
