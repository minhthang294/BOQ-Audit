---
name: boq-audit-v5
description: Bóc tách độc lập từ bản vẽ, rà soát 100% từng dòng BOQ, kiểm đóng hai chiều bản vẽ↔BOQ, chuỗi công việc chức năng, hợp hình học vùng xử lý, quan hệ lắp ghép và số lượng physical instance; xuất PDF đánh dấu chính xác và hỗ trợ downstream dự toán. Ưu tiên cầu, cảng, đường, sửa chữa và công trình tạm.
---

# BOQ Audit v5.8

Phiên bản 5.8 — 16/09/2026. Kế thừa v5.7 và bổ sung **Cổng đối chiếu bảng tổng hợp (Summary Reconciliation Gate)** sau khi phát hiện các lỗi ở bảng chi tiết có thể bị truyền nguyên vào trang tổng hợp cuối của từng cầu/hạng mục. Từ phiên bản này, kiểm xong bảng chi tiết chưa được coi là hoàn thành: bắt buộc xác định toàn bộ trang tổng hợp, map từng dòng tổng hợp về nguồn chi tiết, cộng lại độc lập, truy lỗi gốc tới tổng hợp và giữ trạng thái mở cho mọi dòng tổng hợp không có nguồn hoặc còn tham số chưa chốt. PDF Annotation QA v2 và toàn bộ functional closure của v5.7 vẫn giữ nguyên.

## Chọn chế độ và đọc tài liệu

- **Rà soát BOQ:** tự bóc tách rồi đối chiếu hai chiều; không coi BOQ là đáp án.
- **Bóc tách mới:** dựng danh mục cấu kiện/công tác từ hồ sơ; không cần có BOQ để bắt đầu.
- **Hỗ trợ dự toán:** dùng khối lượng có trạng thái rõ, kiểm mã/đơn vị/định mức/nguồn giá riêng.
- Chỉ làm chế độ người dùng yêu cầu. Khi yêu cầu chưa rõ, bắt đầu phần chung có ích; chỉ hỏi dữ kiện làm thay đổi kết quả mà hồ sơ không cung cấp.
- Mọi phiên đọc [Hồ sơ và bằng chứng](references/evidence.md) và [Dữ liệu, kết luận và đầu ra](references/data-and-delivery.md).
- Khi rà soát bảng chi tiết hoặc BOQ, đọc [Kiểm từng dòng và hình học chức năng](references/detail-table-audit.md).
- Với mọi hồ sơ có bảng KL hoặc chuỗi công tác phụ thuộc hình học, đọc [Functional closure và kiểm quan hệ công việc](references/functional-closure.md).
- Khi bóc tách, đọc nhóm công tác liên quan trong [Quy tắc chuyên môn](references/takeoff.md).
- Khi áp giá/kiểm dự toán, đọc [Dự toán](references/estimating.md).
- Khi người dùng muốn cải thiện hồ sơ để dễ kiểm, đọc [Hồ sơ dễ audit](references/drawing-auditability.md).
- Khi tạo PDF đánh dấu, đọc và thực hiện đầy đủ [Đánh dấu PDF và kiểm tọa độ](references/pdf-annotation-qa.md).
- Khi sửa skill hoặc đánh giá hành vi, đọc [Tình huống hồi quy](references/regression.md). Các số ví dụ không phải dữ liệu dự án hiện tại.

## Các điều kiện không được bỏ qua

1. Xác định mục đích đo bóc, phạm vi và bộ hồ sơ có hiệu lực. Bản vẽ, chỉ dẫn, sửa đổi và điều kiện hợp đồng được xem xét đúng phạm vi; không tự đặt thứ tự ưu tiên pháp lý khi dự án chưa quy định.
2. Kiểm số trang PDF thực và lập bản đồ trang/tờ/hình/revision. Đọc toàn bộ phạm vi được giao; không dừng theo preview. Thiếu hồ sơ không đồng nghĩa BOQ sai.
3. Dựng mô hình công trình và sổ cấu kiện vật lý trước khi dùng số BOQ để so sánh. Trong PDF chung, có thể nhận diện bảng để định vị nhưng không lấy tổng bảng làm đầu vào hình học.
4. Đếm theo vị trí, không suy từ số thứ tự cuối, pattern, đối xứng hoặc tự nhân hai. Kiểm ID nhảy số, A/B, hiện hữu, thay thế, lặp và ngoài phạm vi.
5. Map cùng cấu kiện qua mặt bằng, dọc, ngang, mặt cắt và chi tiết. Kiểm đầu leader/đường nối trước khi ghép nhãn. Nhiều hình sao chép cùng nguồn không phải nhiều bằng chứng độc lập.
6. Một callout lệch chưa đủ để đổi mô hình. Kiểm revision/note/phạm vi và nguồn độc lập. Chỉ ghi lỗi drafting đã giải trình khi có căn cứ; xác nhận của người dùng phải lưu riêng nguồn, thời điểm và phạm vi.
7. Mỗi công tác giữ riêng: quy cách; số lượng/vị trí; hình học; quy tắc đo bóc; tính toán. Đúng quy cách không làm xanh khối lượng. Xem mọi tham số trong tên/mô tả như dữ liệu kỹ thuật cần kiểm: D, L, t, mác, vật liệu, tiết diện, cấp bền, lớp phủ và chiều sâu.
8. Kiểm chuỗi hình học chức năng: cấu kiện lắp ở đâu, phải bao phủ/vượt/neo/hứng/tiếp xúc phần nào, và kích thước nào chi phối chức năng. Bảng tự cộng đúng không làm chi tiết bản vẽ đúng; chi tiết có một số ghi sai cũng không tự làm khối lượng bảng sai.
9. Với phạm vi “rà soát toàn bộ”, kiểm 100% dòng của từng bảng, kể cả dòng đang đúng. Báo `Đã kiểm N/N dòng`; dòng chưa đủ căn cứ vẫn được tính vào độ phủ xử lý nhưng giữ VÀNG/XÁM, không được ngầm xanh.
10. Gắn loại khối lượng: hình học / đo bóc công tác / mua sắm-chế tạo / nghiệm thu-thanh toán. Không so trực tiếp hai loại khác nhau hoặc tự cộng hao hụt vào hình học.
11. Dựng gross, phần trừ, phần cộng, phần giao và net từ bản vẽ. Ô trắng/hatch ngắt chỉ là dấu hiệu cần kiểm. Xác nhận ô mở và kích thước; trừ trong net khi chứng minh có khoảng rỗng. Khối lượng BOQ áp quy tắc đo bóc riêng.
12. `Tổng BOQ / đơn trọng` chỉ là số suy ngược để tìm chênh lệch. Không dùng số đó chứng minh diện tích, số panel hay số cấu kiện.
13. Mỗi kết luận đúng/sai cần phép kiểm độc lập có nêu rõ độc lập ở đầu vào hoặc cách kiểm nào. Đổi thứ tự cộng hay lặp lại công thức không tạo bằng chứng mới. Nếu không có phép kiểm đủ độc lập, ghi mức kiểm thực tế và giữ kết luận chưa xác nhận.
14. Không đoán số. Khi thiếu, dùng biến chưa biết và tính subtotal có căn cứ. Xấp xỉ, tạm tính và dữ liệu đã xác nhận phải tách riêng; không gọi subtotal là tổng toàn bộ.
15. Tính bằng công thức Excel hoặc mã có thể chạy lại; lưu đầu vào, đơn vị, phép đổi và giá trị trước làm tròn. Công cụ tính không thay thế xác nhận hình học.
16. Kiểm hai chiều: cấu kiện/công tác → BOQ để tìm thiếu; BOQ → cấu kiện/công tác để tìm thừa/trùng/không có căn cứ. Tách một dòng gộp thành các phần kiểm được; không ép quan hệ một-một.
17. Tách số bộ chế tạo, số bộ đồng thời, lượt lắp/tháo, luân chuyển và phần thay thế. Cần biện pháp/tiến độ để xác nhận tái sử dụng; không tự suy số bộ bằng số vị trí.
18. Kiểm lỗi gốc và tác động lan truyền riêng. Truy mọi tham số thay đổi qua công thức dòng, subtotal, bảng tổng hợp, BOQ, định mức/đơn giá và thành tiền. Không đếm lại cùng chi phí bị ảnh hưởng; không tự suy kết luận an toàn chịu lực.
19. Không xác nhận sai chỉ vì số lẻ; kiểm nguồn chính xác, quy tắc làm tròn và ảnh hưởng cộng dồn. Không bỏ qua sai lệch có căn cứ chỉ vì giá trị tiền nhỏ.
20. Khi dữ liệu thay đổi, tìm và tính lại toàn bộ kết quả phụ thuộc, thu hồi màu/kết luận cũ và ghi lịch sử. Không bảo vệ một lỗi đã bị bằng chứng mới bác bỏ.
21. Kiểm mọi tên hình, tên nhịp, số hiệu chi tiết, tiêu đề bảng và khung tên như dữ liệu kỹ thuật. Lập giá trị kỳ vọng từ mô hình công trình rồi đối chiếu theo chiều dài, vị trí và nội dung hình; không tin nhãn để xác định chính đối tượng đang kiểm. Ghi đồng thời trang PDF và số tờ in để không đánh dấu nhầm trang.
22. **PDF Annotation QA v2:** PDF đánh dấu chỉ được phát hành sau khi tách riêng `technical_qa` và `annotation_qa`, và **mọi annotation_id đều QA_PASS ở crop mục tiêu**. Đúng nội dung nhưng underline/box/leader lệch chữ, số, ô bảng hoặc cấu kiện vẫn là FAIL. Với bản vẽ xoay/scan/không có text layer hoặc đã từng lỗi transform, mặc định xác định mục tiêu trên ảnh render cố định 300 dpi và dùng pipeline pixel-native; chỉ dùng vector/PDF-coordinate mode khi phép biến đổi đã được kiểm bằng target crop. Chi tiết nhỏ ưu tiên underline; khoanh chỉ dùng cho ô/vùng hình học; leader phải kết thúc đúng target.
23. **Cổng định danh hồ sơ bắt buộc trước bóc tách:** lập ledger cho *mọi trang* gồm `project_name, owner/client, location, drawing_title, drawing_no, sheet_no, revision, issue/date`. So thân bản vẽ với title block và so chéo toàn bộ bộ hồ sơ. Sai dự án/chủ đầu tư/địa điểm, số bản vẽ trùng cho hai tờ khác nhau, tên tờ không khớp thân hình hoặc revision bất thường phải được ghi issue trước khi kết luận kỹ thuật. Không được bỏ qua trang không có bảng KL.
24. **Tiêu đề chi tiết là nguồn tham số:** mọi D/L/B/H/t/vật liệu ghi trong tên hình, tiêu đề chi tiết, caption hoặc tên tấm phải vào ma trận tham số ngang hàng với callout và bảng. Bắt buộc kiểm bộ ba `detail title ↔ callout/leader ↔ bảng/BOQ`; nếu một tiêu đề ghi “dày 1mm” nhưng callout/bảng ghi 0,635mm thì phải nêu xung đột, không coi tiêu đề là chữ trang trí.
25. **Đóng BOM từ hình trước khi duyệt bảng:** với cụm lắp ráp (barie, biển báo, lan can, giàn giáo, neo, tấm vỏ...), lập `assembly → component → support/fastener → foundation` và map *từng component* sang dòng bảng. Một cụm có nhiều chân/cột/móng phải đếm đúng multiplicity; không mặc định một object = một support. Mọi chi tiết xuất hiện trên hình nhưng không có dòng tương ứng phải được truy gộp/phạm vi trước khi kết luận không thiếu.
26. **Second-pass mù bắt buộc:** sau khi có danh sách lỗi lần 1, thực hiện một lượt rà lại độc lập không dùng danh sách lỗi cũ làm checklist chính. Ưu tiên (a) trang chưa có lỗi/annotation, (b) dòng đã xanh, (c) trang không có bảng, (d) title block, note, tiêu đề chi tiết và các assembly. Chỉ phát hành sau khi ghi `second_pass = PASS` hoặc liệt kê lỗi mới tìm được.
27. **Kiểm chính sách làm tròn và loại đại lượng:** không gọi số là “phù hợp làm tròn” nếu không tái lập quy tắc làm tròn đang dùng. So các dòng cùng bảng để phát hiện truncate/round không nhất quán. Nếu tên dòng là vật liệu (kg/m, thép hình...) nhưng quantity lại đúng bằng diện tích mặt/chu vi của assembly, phải tách `material quantity` với `work/assembly quantity` và yêu cầu quy tắc đo bóc/mã công tác trước khi xanh.

28. **Đóng hai chiều Drawing ↔ BOQ bắt buộc:** mỗi dòng BOQ phải có ít nhất một `drawing_anchor` chỉ ra chính xác vùng/chi tiết/hình học sinh ra khối lượng; đồng thời mọi vùng vật liệu/cấu kiện/công tác thể hiện trên bản vẽ phải map được sang BOQ hoặc được giải thích là included/excluded/temporary. Dòng BOQ không tìm được hình học nguồn là `ORPHAN_BOQ_ROW`; hình/cấu kiện không map được BOQ là `ORPHAN_DRAWING_OBJECT`. Không cho XANH trước khi đóng hoặc giải trình.
29. **Functional work-chain:** với công tác có mục đích xử lý bề mặt, neo, bao phủ, hứng, trám, dán, sơn, khoan hoặc hoàn trả, phải xác định `parent geometry → prerequisite work → downstream work`. Khối lượng công tác phụ phải được suy từ footprint/biên chức năng của công tác chính, không chỉ lấy số trong bảng.
30. **Geometric union cho công tác bề mặt:** diện tích mài/vệ sinh/tạo nhám chuẩn bị cho nhiều lớp dán hoặc phủ được tính theo **hợp hình học (union)** của các footprint cần xử lý, không cộng diện tích từng lớp nếu chúng chồng nhau. Lớp nhỏ nằm trọn trong vùng đã xử lý không tạo thêm diện tích; lớp lớn hơn chỉ cộng phần vượt ra. Các tỷ lệ như trám vá 10% phải bám theo parent quantity đã khép kín.
31. **Interface compatibility:** khi hai cấu kiện/công tác tiếp xúc hoặc lắp vào nhau, kiểm quan hệ bắt buộc giữa thông số hai phía, ví dụ `D_hole > D_bar`, khe lắp đủ dung sai/keo, chiều dài neo đủ phần cắm, tấm/máng đủ phủ. Callout nào vi phạm interface hoặc mâu thuẫn với note chức năng phải flag dù tổng bảng đang khớp.
32. **Dimension-chain reconstruction:** không tin một `L=` đơn lẻ nếu thanh/cấu kiện chạy qua nhiều đoạn. Dựng lại chiều dài từ chuỗi kích thước chức năng đầu–giữa–cuối; mọi đoạn ẩn/offset/neo phải có bằng chứng. Nếu tổng chuỗi khác detail, báo lỗi detail và truy downstream tới bảng.
33. **Physical Instance Ledger:** với cấu kiện lặp (khung treo, cột, móng, panel, neo, biển...), đếm station/vị trí vật lý trên hình trước, sau đó nhân theo phía/lớp/nhịp đã chứng minh. Bảng số lượng không được dùng làm đầu vào cho phép đếm. Lưu `instance_id, station, side, span/support, view_evidence` để tránh 20↔24 hoặc tự nhân hai.
34. **Label/spec uniqueness:** trong cùng assembly/phạm vi, một ID kỹ thuật chỉ được map tới một tổ hợp `spec + kích thước + chức năng` tại một revision. Nếu cùng `3a` trỏ tới 40×80×1,4 ở bảng/chi tiết nhưng 30×60×1,8 ở view khác, flag `LABEL_COLLISION`; không bỏ qua vì khối lượng vẫn đúng.
35. **Duplicate-vector anomaly:** nếu hai dòng khác chức năng lại có cùng vector khối lượng theo vị trí/khe/nhịp một cách bất thường, kiểm nguy cơ copy/reference sai. Ví dụ dòng bê tông mới có dãy khối lượng trùng y hệt dòng phá dỡ là tín hiệu bắt buộc tái dựng hình học; không coi là bằng chứng sai duy nhất nhưng phải kích hoạt kiểm sâu.
36. **Peer-component control:** khi mố/trụ, nhịp 8m/10m hoặc hai cấu tạo tương đồng có cùng nguyên lý nhưng một bên thiếu callout/vật liệu, dùng cấu tạo tương đồng làm *control* để đặt câu hỏi và tìm thiếu; không copy giá trị sang nếu hình học khác. Đây là phép kiểm phát hiện thiếu ký hiệu/callout, không phải quyền tự suy thiết kế.
37. **Annotation precision release gate:** trước khi xuất PDF, mỗi issue phải có `target_crop` riêng ở độ phân giải đủ đọc, `target_type` (text/number/table_cell/callout/geometry), `mark_style`, `pixel_bbox/anchor`, `note_bbox`, `leader_endpoint` và hai trạng thái độc lập `technical_qa_status`, `annotation_qa_status`. Không được dùng contact sheet/toàn trang làm bằng chứng duy nhất cho dấu nhỏ. Một annotation chỉ PASS khi crop sau đánh dấu cho thấy dấu bám đúng toàn bộ và **chỉ** đúng đối tượng mục tiêu; nếu quá nhỏ hoặc dày nét thì bỏ box và dùng underline/tick/marker. Không phát hành khi `annotation_qa_pass_count < annotation_target_count`.


38. **Cổng đối chiếu bảng tổng hợp bắt buộc:** sau khi kiểm bảng chi tiết, phải xác định **tất cả** trang/bảng tổng hợp cuối của từng cầu, nhịp, hạng mục hoặc phân khu. Không được giả định bảng tổng hợp đúng chỉ vì bảng chi tiết đã kiểm. Mỗi dòng tổng hợp phải được truy ngược về một hoặc nhiều dòng nguồn và được cộng lại độc lập theo cùng phạm vi, đơn vị, revision. Chỉ phát hành khi ghi rõ `summary_pages_checked`, `summary_rows_checked/total` hoặc, với hồ sơ scan không thể đếm máy đáng tin cậy, ghi rõ mức độ phủ trực quan và không tuyên bố N/N giả tạo.
39. **Sổ dòng dõi tổng hợp (Summary Lineage Ledger):** với mỗi dòng tổng hợp lưu ít nhất `summary_page, summary_section, summary_row, source_pages, source_tables, source_rows, aggregation_rule, reported_total, audited_total, delta, status`. Nếu dòng tổng hợp không tìm được nguồn chi tiết thì gắn `ORPHAN_SUMMARY_ROW`; nếu subtotal/khối lượng chi tiết không xuất hiện ở tổng hợp và không có giải thích thì gắn `MISSING_SUMMARY_MAPPING`.
40. **Truy lỗi gốc tới tổng hợp và chống đếm lặp:** mọi lỗi gốc làm đổi khối lượng phải được propagate theo chuỗi `chi tiết → subtotal → bảng tổng hợp → BOQ/dự toán`. Nếu nhiều dòng chi tiết cùng đổ vào một dòng tổng hợp, chỉ cộng delta đã chuẩn hóa; không cộng lặp cả giá trị cũ lẫn subtotal. Dòng tổng hợp còn mang giá trị cũ sau khi chi tiết được sửa là lỗi downstream riêng nhưng liên kết về cùng root cause.
41. **Không tự chốt dòng tổng hợp từ tham số chưa có drawing anchor:** nếu bảng chi tiết và bảng tổng hợp cùng mang một giá trị nhưng phép tính nguồn chứa tham số chưa chứng minh trên bản vẽ (ví dụ chiều sâu/chiều dài ẩn), giữ CAM/OPEN ở cả hai lớp. Việc “chi tiết khớp tổng hợp” không biến tham số vô căn cứ thành đúng.

## Quy trình thực hiện

1. **Tiếp nhận:** xác định chế độ, nguồn, phạm vi, revision, mục đích và phần thiếu.
2. **Mô hình:** công trình → vị trí → cấu kiện → công tác; ghi phạm vi sửa/chế tạo/hiện hữu.
3. **Bằng chứng:** nhận diện hình/leader, lấy kích thước, kiểm chéo, ghi nguồn đến từng biến.
4. **Định danh hồ sơ + hình:** lập ledger title block cho mọi trang và kiểm tính duy nhất của số bản vẽ/revision; từ mô hình lập bảng kỳ vọng `view_id → loại/chiều dài/vị trí → nhịp/cấu kiện`; kiểm tên hình, tên nhịp, số hiệu chi tiết, caption tham số và khung tên, kể cả hình không tham gia trực tiếp vào phép tính.
5. **Chức năng + closure:** dựng `drawing object ↔ work item ↔ BOQ row`; kiểm chuỗi hình học chức năng, parent/child work-chain, interface và ma trận cùng cấu kiện qua các hình chiếu.
6. **Bóc tách:** lập phép tính hình học độc lập; với công tác bề mặt dựng union footprint; với thanh/cấu kiện dựng dimension chain; với cấu kiện lặp dựng physical instance ledger; áp quy tắc đo bóc riêng; kiểm đơn trọng và hệ số.
7. **Từng dòng:** với mỗi bảng, kiểm tên/tham số, số lượng, L/B/H/t/D, hệ số, đơn trọng, công thức, dòng, subtotal, tổng và downstream; ghi N/N.
8. **Kiểm:** kiểm chéo độc lập, sai đơn vị, bỏ sót/trùng, tổng theo nhóm và tổng chung; đóng BOM hai chiều hình↔bảng, chạy orphan check, label/spec uniqueness, interface compatibility, duplicate-vector anomaly và peer-component control.
9. **Đối chiếu bảng tổng hợp:** xác định toàn bộ trang tổng hợp của từng cầu/hạng mục; dựng Summary Lineage Ledger; truy từng dòng tổng hợp về nguồn chi tiết, cộng lại độc lập, ghi delta và trạng thái; kiểm cả chiều `chi tiết → tổng hợp` lẫn `tổng hợp → chi tiết`.
10. **Đối chiếu:** cùng khái niệm, vị trí, phạm vi, loại khối lượng, đơn vị và revision.
11. **Second-pass mù:** rà lại các trang không lỗi, dòng xanh, trang không bảng, title block/note/detail-title và assembly mà không dựa vào danh sách lỗi lần 1.
12. **Kết luận:** trạng thái từng lớp, lỗi gốc, tác động, câu hỏi cần giải trình và độ phủ; ghi kết quả second-pass.
13. **Nếu yêu cầu dự toán:** kiểm mã/định mức/giá, nội dung đã bao gồm, chi phí và ngày áp dụng.
14. **Phát hành:** kiểm lại kết luận đỏ/xanh, lỗi cũ đã rút, công thức, N/N, ledger định danh hồ sơ, kết quả second-pass và từng vùng đánh dấu ở ảnh render; báo rõ phần chưa hoàn thành.

## Tiêu chuẩn kết thúc

Được phát hành báo cáo một phần khi có giá trị sử dụng, nhưng phải ghi rõ phạm vi đã kiểm và chưa kiểm. Chỉ nói hoàn thành trong phạm vi khi mọi cấu kiện/công tác và mọi dòng bảng thuộc phạm vi đã được xử lý hoặc có trạng thái mở và lý do; từng bảng có N/N khi có thể xác định đáng tin cậy; **mọi trang tổng hợp đã qua Summary Reconciliation Gate**, dòng tổng hợp có lineage hoặc trạng thái orphan/open rõ ràng; tổng hợp khớp với nguồn chi tiết sau audit; nguồn truy được; phép tính tái lập được; deliverable đã hứa đã tạo và QA. Không gọi `FINAL/hoàn thành` khi còn thiếu deliverable. Không tuyên bố chính xác tuyệt đối, đã đọc hình chưa xem, đã chạy công cụ chưa chạy hoặc đã kiểm 100% chỉ vì đọc hết trang.
