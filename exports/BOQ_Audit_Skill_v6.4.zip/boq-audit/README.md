# BOQ Audit v6.4

Bộ skill dùng cho rà soát bản vẽ, bóc tách khối lượng, kiểm BOQ và hỗ trợ kiểm dự toán
cầu / công trình giao thông.

## Điểm cốt lõi của v6.4

- Bản vẽ và hồ sơ kỹ thuật là bằng chứng; BOQ là đối tượng cần kiểm.
- Dựng mô hình vật lý trước khi so số BOQ.
- Kiểm 100% dòng trong phạm vi đã nhận.
- Kiểm hai chiều `Drawing ↔ Detail Table ↔ Summary ↔ BOQ ↔ Estimate`.
- Mọi phép tính quan trọng phải có `CALC-ID`, đầu vào, đơn vị, nguồn và có thể chạy lại.
- Có `Coverage Gate` trước phát hành.
- Bắt buộc chạy **3 pass**:
  1. First Pass — audit chính và phủ toàn bộ phạm vi.
  2. Second Pass — blind independent recalculation / anti-confirmation.
  3. Third Pass — forensic micro-detail review + false-positive closure.
- Không giữ một lỗi chỉ vì pass trước đã gắn cờ.
- Nếu thiếu bằng chứng hình học: ghi `CẦN XÁC NHẬN / KHÔNG ĐỦ BẰNG CHỨNG`, không đoán theo tỷ lệ hình vẽ.
- PDF đánh dấu chỉ phát hành khi annotation QA đạt.

- Sequence gate có nhận biết reset: không chỉ bắt STT lặp mà kiểm expected index cho toàn subsection.
- Row-by-row detail↔summary parity: name/spec/unit/value/scope đều phải khớp.
- Discrete quantity gate mạnh hơn cho `cái/bộ/biển/lỗ/cọc...`.
- FRP spec gate: loại sợi và chiều dày được audit độc lập.
- Symmetry/paired-geometry closure và downstream recalculation khi một dimension gốc thay đổi.

## Cấu trúc gói

- `SKILL.md`: prompt/skill chính.
- `references/`: toàn bộ tài liệu tham chiếu bắt buộc và module chuyên môn.
- `schemas/`: schema dữ liệu có cấu trúc cho ledgers.
- `templates/`: CSV/JSON mẫu để agent tạo dữ liệu.
- `legacy/`: bản skill cũ để truy lịch sử phát triển.
- `PACKAGE_MANIFEST.txt`: checksum SHA-256 để kiểm gói đủ file.

## Cách dùng

Khi chạy audit:
1. Đọc `SKILL.md`.
2. Đọc tối thiểu các file được chỉ định trong mục "Reference loading policy".
3. Tạo Run Manifest.
4. Chạy First Pass → Second Pass → Third Pass.
5. Chỉ phát hành sau Coverage Gate.


## Ngôn ngữ báo cáo
Mặc định mọi deliverable người dùng nhìn thấy phải bằng tiếng Việt; schema nội bộ có thể giữ key tiếng Anh. Trước export bắt buộc Language QA.


## Bổ sung v6.3 — Geometry Assumption Control
- User claim không được override drawing evidence.
- Assumption Ledger bắt buộc khi geometry chưa khóa.
- Tách `INDEPENDENT_TAKEOFF` khỏi `RECONCILIATION_CHECK` và `SENSITIVITY_CHECK`.
- Cấm target-fitting/back-solve để chứng minh BOQ.
- Side A/B phải được xác nhận riêng.
- Scope partition chống cộng trùng giữa assembly, reinforcement và work items riêng.
- Complex geometry không được tự thay bằng primitive toán học nếu bản vẽ không chứng minh.

## Quy trình checkpoint-v1 — 2026-10-15

Đọc `references/execution-workflow.md` khi bắt đầu hoặc tiếp tục sau mất ngữ cảnh. Inventory khởi tạo checkpoint và checklist tất cả R-*; không ghi đè audit đang làm. Chạy `validate_run.py WORK --stage pass1`, rồi pass2, pass3 và cuối cùng bỏ `--stage` để kiểm release. Mỗi gate chặn case chưa kiểm, thiếu evidence hoặc pending recheck; Pass 2/3 phải có page coverage, Pass 3 phải phủ từng target của case áp dụng. Memory thiếu phải khai báo.

Audit cũ cần bổ sung contract/checkpoint/checklist bằng kết quả kiểm thực, không tự đánh dấu đã hoàn thành. Các gate chỉ kiểm metadata; kiểm thử synthetic không chứng minh model tìm đủ lỗi kỹ thuật trong hồ sơ thực.

## Gói phát hành 6.4

Giải nén ZIP để lấy thư mục `boq-audit/`, đặt tại thư mục skills của công cụ đang dùng. Điểm vào là `boq-audit/SKILL.md`; giữ nguyên tên skill `boq-audit` để các lời gọi hiện có tiếp tục nhận diện. Protocol hiện hành là `references/protocol-v6.4.md`; các protocol cũ chỉ để truy lịch sử.

Kiểm tra gói từ thư mục `boq-audit`: `sha256sum --check PACKAGE_MANIFEST.txt` (hai dòng tiêu đề không phải bản ghi checksum). Chạy kiểm thử bằng `python3 -m unittest discover -s tests -v`. Script kiểm metadata yêu cầu manifest v6.4; không đổi số phiên bản audit cũ rồi coi là đã đạt yêu cầu mới.
