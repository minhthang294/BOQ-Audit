"""Run: python3 -m unittest discover .agents/skills/boq-audit/tests -v"""
import importlib.util, pathlib, tempfile, unittest, json, sys, types
ROOT=pathlib.Path(__file__).parents[1]
def module(filename):
    p=ROOT/'scripts'/filename
    spec=importlib.util.spec_from_file_location(p.stem,p)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
class TestBoqSkill(unittest.TestCase):
    def test_sanity_checks(self):
        f=module('sanity_checks.py').anomalies([
            {'row_id':'a','section_id':'s','stt':1,'unit':'cái','reported_quantity':2},
            {'row_id':'b','section_id':'s','stt':3,'unit':'bộ','reported_quantity':'2,5'},
            {'row_id':'c','section_id':'different','stt':1,'unit':'m','reported_quantity':2.2},
        ])
        self.assertEqual({i['anomaly'] for i in f},{'STT_SEQUENCE','DISCRETE_FRACTION'})
    def test_incomplete_manifest_cannot_pass(self):
        with tempfile.TemporaryDirectory() as d:
            (pathlib.Path(d)/'run_manifest.json').write_text(json.dumps({'protocol_version':'v6.4','scope_pages_total':0,'pass1_complete':True,'pass2_complete':True,'pass3_complete':True}))
            for name in ('page_ledger','detail_rows','summary_lineage','calculation_ledger','issues','pass2_review','pass3_review','annotation_qa'):
                (pathlib.Path(d)/(name+'.json')).write_text('[]')
            (pathlib.Path(d)/'assumption_ledger.json').write_text('[]')
            result=module('validate_run.py').audit(d)
            self.assertEqual(result['candidate_release_status'],'BLOCKED')
            self.assertFalse(result['automatic_publication_allowed'])
            self.assertGreater(len(result['blocking_checks']),4)
    def test_render_page_bounds(self):
        parse=module('render_pdf_pages.py').page_selection
        self.assertEqual(parse('2,4-5,4',5),[2,4,5])
        with self.assertRaises(ValueError):parse('1-30',30,25)
        with self.assertRaises(ValueError):parse('0,1',30)
    def test_original_provenance(self):
        p=json.loads((ROOT/'PROVENANCE.json').read_text())
        self.assertEqual(p['original_file_count'],46)
        self.assertEqual(len(p['files']),46)
    def test_inventory_bootstraps_v64_files_and_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d); source=root/'source.pdf'; source.write_bytes(b'pdf')
            class PDF:
                needs_pass=False
                page_count=2
                def __enter__(self): return self
                def __exit__(self,*args): pass
            fake=types.SimpleNamespace(open=lambda _path:PDF())
            old=sys.modules.get('fitz'); sys.modules['fitz']=fake
            try:
                inventory=module('inventory_pdf.py').inventory
                inventory([str(source)],root/'run')
                before=(root/'run/run_manifest.json').read_bytes()
                with self.assertRaises(FileExistsError): inventory([str(source)],root/'run')
                self.assertEqual(before,(root/'run/run_manifest.json').read_bytes())
            finally:
                if old is None: sys.modules.pop('fitz',None)
                else: sys.modules['fitz']=old
            run=root/'run'; manifest=json.loads((run/'run_manifest.json').read_text())
            self.assertEqual(manifest['protocol_version'],'v6.4')
            self.assertEqual(manifest['execution_contract'],'checkpoint-v1')
            checks=json.loads((run/'regression_checks.json').read_text())
            self.assertEqual(len(checks),23)
            self.assertTrue(all(c['status']=='NOT_CHECKED' for c in checks))
            self.assertEqual(json.loads((run/'checkpoint.json').read_text())['stage'],'pass1')
            self.assertTrue((run/'assumption_ledger.json').is_file())
            self.assertEqual(json.loads((run/'page_ledger.json').read_text())[1]['page_id'],'DOC-001-P00002')
    def test_validator_rejects_missing_inventoried_page(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            (root/'run_manifest.json').write_text(json.dumps({'protocol_version':'v6.4','document_inventory':[{'doc_id':'DOC-001','filename':'a.pdf','page_count':2,'sha256':'hash'}],'scope_pages_total':1}))
            (root/'page_ledger.json').write_text(json.dumps([{'page_id':'DOC-001-P00001','source_pdf':'a.pdf','pdf_page':1,'status':'NOT_CHECKED'}]))
            result=module('validate_run.py').audit(d)
            self.assertTrue(any('exactly cover every inventoried document page' in x for x in result['blocking_checks']))
    def test_target_based_input_cannot_validate_independent_takeoff(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            (root/'run_manifest.json').write_text(json.dumps({'protocol_version':'v6.4'}))
            for name in ('page_ledger','detail_rows','summary_lineage','issues','pass2_review','pass3_review','annotation_qa'):
                (root/(name+'.json')).write_text('[]')
            (root/'assumption_ledger.json').write_text(json.dumps([{'assumption_id':'ASM-1','evidence_class':'RECONCILIATION'}]))
            (root/'calculation_ledger.json').write_text(json.dumps([{'calc_id':'CALC-1','formula':'a','inputs':[1],'source_anchors':['p1'],'unit':'m','raw_result':1,'pass1_result':1,'pass2_result':1,'pass3_result':1,'calculation_class':'INDEPENDENT_TAKEOFF','assumption_ids':['ASM-1']}]))
            result=module('validate_run.py').audit(d)
            self.assertTrue(any('non-independent input' in x for x in result['blocking_checks']))
if __name__=='__main__':unittest.main()
