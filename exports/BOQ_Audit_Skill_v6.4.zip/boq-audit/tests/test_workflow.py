"""Synthetic metadata contracts only; these fixtures are not engineering evidence."""
import copy
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).parents[1]
spec = importlib.util.spec_from_file_location('validate_run', ROOT / 'scripts/validate_run.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'work'
        self.root.mkdir()
        self.cases = re.findall(r'^## (R-\d+) ', (ROOT / 'references/regression.md').read_text(), re.M)
        manifest = json.loads((ROOT / 'templates/run_manifest.json').read_text())
        # Fully populated synthetic fixture, so deleting one requirement isolates that gate.
        for key, value in manifest.items():
            if value is False:
                manifest[key] = True
        manifest.update(document_inventory=[{'doc_id':'DOC-001','filename':'fixture.pdf','page_count':1,'sha256':'synthetic'}],
                        scope_pages_total=1,detail_rows_total=1,summary_rows_total=1,
                        sequence_sections_total=1,sequence_sections_checked=1,
                        discrete_rows_total=1,discrete_rows_checked=1,
                        references_read=sorted(validator.MANDATORY_REFS),
                        memory_lookup={'status':'UNAVAILABLE','sources':[],'reason':'Synthetic offline fixture'},
                        deliverables={'excel':'../output/report.xlsx','annotated_pdf':'../output/report.pdf'})
        self.data = {
            'run_manifest':manifest,
            'checkpoint':json.loads((ROOT/'templates/checkpoint.json').read_text()),
            'page_ledger':[{'page_id':'DOC-001-P00001','source_pdf':'fixture.pdf','pdf_page':1,'status':'VERIFIED','evidence_anchors':['fixture p1']}],
            'detail_rows':[{'row_id':'ROW-1','source_anchor':'fixture p1 row1','spec_status':'VERIFIED','qty_status':'VERIFIED','status':'VERIFIED','unit':'cái','integer_sanity_checked':True}],
            'summary_lineage':[{'summary_row_id':'SUM-1','source_anchor':'fixture p1 summary1','source_rows':['ROW-1'],'status':'VERIFIED','name_spec_match':True,'unit_match':True,'scope_match':True}],
            'assumption_ledger':[],
            'calculation_ledger':[{'calc_id':'CALC-1','formula':'n','inputs':{'n':1},'source_anchors':['fixture p1'],'unit':'cái','raw_result':1,'pass1_result':1,'pass2_result':1,'pass3_result':1,'calculation_class':'INDEPENDENT_TAKEOFF','assumption_ids':[]}],
            'issues':[],
            'annotation_qa':[],
            'regression_checks':[{'case_id':cid,'status':'NOT_APPLICABLE','target_ids':[], 'evidence_anchors':['fixture p1 scope'],'reason':'Not present in this synthetic metadata fixture'} for cid in self.cases],
        }
        for n in (2,3):
            self.data[f'pass{n}_review'] = [{'review_id':f'REV-{n}','pass_no':n,'target':'DOC-001-P00001','page_ids':['DOC-001-P00001'],'evidence':['fixture p1'],'method':'Synthetic metadata test','result':'fixture only','case_ids':[]}]
        output = self.root.parent / 'output'
        output.mkdir()
        for name in ('report.xlsx','report.pdf'):
            (output/name).write_bytes(b'Synthetic nonempty artifact, not a real report')

    def run_gate(self, stage='release'):
        for stem, data in self.data.items():
            (self.root/(stem+'.json')).write_text(json.dumps(data))
        return validator.audit(self.root,stage)

    def assertBlocked(self, fragment, stage='release'):
        result = self.run_gate(stage)
        self.assertEqual(result['candidate_release_status'],'BLOCKED',result)
        self.assertTrue(any(fragment in s for s in result['blocking_checks']),result)

    def test_old_protocol_requires_explicit_migration(self):
        self.data['run_manifest']['protocol_version'] = 'v6.3'
        self.assertBlocked('Wrong protocol_version')

    def test_complete_metadata_with_sibling_output(self):
        result = self.run_gate()
        self.assertEqual(result['candidate_release_status'],'READY_FOR_ENGINEER_REVIEW',result)
        self.assertFalse(result['automatic_publication_allowed'])
        self.assertEqual(result['protocol_version'],'v6.4')

    def test_pass1_does_not_require_later_work_or_artifacts(self):
        for name in ('pass2_review','pass3_review','annotation_qa'):
            del self.data[name]
        for flag in ('pass2_complete','pass3_complete','annotation_qa_pass','language_qa_pass','target_fit_check_complete','false_positive_propagation_complete'):
            self.data['run_manifest'][flag] = False
        self.data['run_manifest']['deliverables'] = {}
        for key in ('pass2_result','pass3_result'):
            del self.data['calculation_ledger'][0][key]
        result = self.run_gate('pass1')
        self.assertEqual(result['candidate_release_status'],'METADATA_STAGE_COMPLETE',result)
        self.assertBlocked('pass2_complete','pass2')

    def test_each_bundled_case_is_required(self):
        original = self.data['regression_checks']
        for cid in self.cases:
            with self.subTest(case=cid):
                self.data['regression_checks'] = [r for r in original if r['case_id']!=cid]
                self.assertBlocked('Missing regression cases: '+cid)

    def test_unchecked_case_and_unsupported_na_are_blocked(self):
        row = self.data['regression_checks'][0]
        row['status'] = 'NOT_CHECKED'
        self.assertBlocked('not checked','pass1')
        row['status'] = 'NOT_APPLICABLE'
        row['evidence_anchors'] = []
        self.assertBlocked('lacks source evidence','pass1')

    def test_applicable_case_requires_targets_and_pass3_revisit(self):
        row = self.data['regression_checks'][0]
        row['status'] = 'CHECKED'
        self.assertBlocked('lacks targets')
        row['target_ids'] = ['ROW-1']
        self.assertBlocked('did not revisit regression cases')
        self.data['pass3_review'][0]['case_ids'] = [row['case_id']]
        self.data['pass3_review'][0]['target_ids'] = ['ROW-1']
        self.assertEqual(self.run_gate()['candidate_release_status'],'READY_FOR_ENGINEER_REVIEW')

    def test_pass3_cannot_sample_one_target_to_close_whole_case(self):
        row = self.data['regression_checks'][0]
        row.update(status='CHECKED',target_ids=['ROW-1','CALC-1'])
        review = self.data['pass3_review'][0]
        review.update(case_ids=[row['case_id']],target_ids=['ROW-1'])
        self.assertBlocked('unchecked targets: CALC-1')
        review['target_ids'].append('CALC-1')
        self.assertEqual(self.run_gate()['candidate_release_status'],'READY_FOR_ENGINEER_REVIEW')

    def test_cli_writes_stage_report_and_returns_blocked_exit(self):
        self.run_gate('pass1')
        command = [sys.executable,str(ROOT/'scripts/validate_run.py'),str(self.root),'--stage','pass1']
        result = subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        report = self.root/'stage_pass1_result.json'
        self.assertEqual(json.loads(report.read_text())['candidate_release_status'],'METADATA_STAGE_COMPLETE')
        self.data['checkpoint']['pending_rechecks'] = [{'reason':'correction'}]
        self.run_gate('pass1')
        result = subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(result.returncode,2,result.stderr)
        self.assertEqual(json.loads(report.read_text())['candidate_release_status'],'BLOCKED')

    def test_memory_case_cannot_disappear(self):
        self.data['run_manifest']['memory_cases_consulted'] = ['MEM-01']
        self.assertBlocked('MEM-01')
        row = copy.deepcopy(self.data['regression_checks'][0])
        row['case_id'] = 'MEM-01'
        self.data['regression_checks'].append(row)
        self.assertBlocked('lacks memory source')
        row['memory_source'] = 'project-local lesson with source anchor'
        self.assertEqual(self.run_gate()['candidate_release_status'],'READY_FOR_ENGINEER_REVIEW')

    def test_missing_memory_disposition_blocks(self):
        self.data['run_manifest']['memory_lookup']['status'] = 'NOT_CHECKED'
        self.assertBlocked('Memory lookup has no disposition','pass1')

    def test_corrected_geometry_pending_recheck_blocks_despite_pass_flags(self):
        self.data['checkpoint']['pending_rechecks'] = [{'reason':'Dimension corrected','target_ids':['CALC-1','SUM-1'],'source_anchors':['fixture p1']}]
        self.assertBlocked('Pending rechecks','pass1')

    def test_review_flags_cannot_replace_page_coverage(self):
        for n in (2,3):
            with self.subTest(pass_no=n):
                self.data[f'pass{n}_review'][0]['page_ids'] = ['UNKNOWN-PAGE']
                self.assertBlocked(f'Pass {n} reviews do not exactly cover')
                self.data[f'pass{n}_review'][0]['page_ids'] = ['DOC-001-P00001']

    def test_unresolved_without_issue_never_becomes_all_clear(self):
        for stem, key in (('page_ledger','status'),('detail_rows','qty_status'),('summary_lineage','status')):
            with self.subTest(ledger=stem):
                self.data[stem][0][key] = 'UNRESOLVED'
                result = self.run_gate()
                self.assertEqual(result['candidate_release_status'],'PARTIAL_WITH_OPEN_ITEMS_REVIEW_REQUIRED',result)
                self.assertEqual(result['open_issue_count'],0)
                self.assertGreater(result['open_record_count'],0)
                self.data[stem][0][key] = 'VERIFIED'

    def test_nonempty_unrelated_deliverable_is_rejected(self):
        outside = self.root.parent/'unrelated.xlsx'
        outside.write_bytes(b'unrelated')
        self.data['run_manifest']['deliverables']['excel'] = '../unrelated.xlsx'
        self.assertBlocked('outside audit workdir')

    def test_malformed_regression_does_not_crash(self):
        self.data['regression_checks'] = [None, {'case_id':[]}, {'case_id':'R-01','evidence_anchors':[{}]}]
        self.assertBlocked('Invalid regression record')


if __name__ == '__main__':
    unittest.main()
